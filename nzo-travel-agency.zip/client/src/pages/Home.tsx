import { useEffect, useMemo, useState } from "react";
import {
  ArrowRight,
  ArrowUpRight,
  Banknote,
  BookOpen,
  BriefcaseBusiness,
  CalendarDays,
  Check,
  ChevronDown,
  ChevronRight,
  CircleHelp,
  ClipboardList,
  Clock3,
  FileCheck2,
  FileText,
  Globe2,
  GraduationCap,
  Landmark,
  Languages,
  Linkedin,
  Mail,
  MapPin,
  Menu,
  MessageCircle,
  Plane,
  Route,
  ScanLine,
  Search,
  ShieldCheck,
  Sparkles,
  Stethoscope,
  UsersRound,
  X,
} from "lucide-react";
import ContactForm from "@/components/ContactForm";

type Lang = "fr" | "en";
type CountryKey = "canada" | "schengen" | "france" | "belgique" | "uk" | "usa";

const heroSlides = [
  { image: "/manus-storage/canada_aa440ebc.jpg", fr: "Canada · horizons à explorer", en: "Canada · horizons to explore", alt: "Paysage touristique du Canada" },
  { image: "/manus-storage/paris_c509dd19.jpg", fr: "Paris · études et mobilité", en: "Paris · study and mobility", alt: "Tour Eiffel à Paris" },
  { image: "/manus-storage/london_119f6489.jpg", fr: "Londres · nouvelles perspectives", en: "London · new perspectives", alt: "Monuments de Londres" },
];

type Guide = {
  label: string;
  kicker: string;
  intro: string;
  categories: { name: string; tag: string; icon: typeof Plane; eligibility: string[]; documents: string[]; process: string[] }[];
  admissions: string[];
  official: string;
};


type ResearchField = { fr: string[]; en: string[] };
type ResearchProfile = { calendar: ResearchField; admissions: ResearchField; costs: ResearchField; language: ResearchField; visa: ResearchField; schools: ResearchField };
type ResearchTab = keyof ResearchProfile;

const researchProfiles: Record<CountryKey, ResearchProfile> = {
  canada: {
    calendar: { fr: ["Rentrée d’automne : généralement septembre–décembre; hiver : janvier–avril; été : mai–août.", "UBC Bachelor 2027–2028 : candidature au 15 janvier 2027; les documents et bourses ont parfois des échéances antérieures.", "McGill Advanced Levels : candidature au 15 janvier, pièces au 1er mars. Vérifier chaque programme et son fuseau horaire."], en: ["Fall is usually September–December; winter January–April; summer May–August.", "UBC Bachelor 2027–2028: application deadline January 15, 2027; documents and scholarships may close earlier.", "McGill Advanced Levels: application January 15, supporting documents March 1. Check each programme and time zone."] },
    admissions: { fr: ["Bachelor : diplôme secondaire donnant accès à l’université dans le pays d’origine, relevés et prérequis du programme.", "Master : diplôme universitaire reconnu, relevés, discipline/prérequis, références ou projet selon la faculté.", "Burundi/Rwanda, Cambridge, Edexcel et SAT : aucune équivalence ou note universelle; l’établissement évalue le dossier. PAL/TAL et CAQ Québec peuvent s’appliquer au permis."], en: ["Bachelor: secondary credential granting university access in the country of study, transcripts and programme prerequisites.", "Master: recognised prior degree, transcripts and programme-specific discipline, references or statement.", "Burundi/Rwanda, Cambridge, Edexcel and SAT: no universal equivalency or score; the institution assesses the file. PAL/TAL and Quebec CAQ may apply to the permit."] },
    costs: { fr: ["UBC Bachelor international 2026/27 : exemples d’environ 48 780–67 237 CAD/an selon programme.", "Coût de vie : ville, logement, assurance et livres varient; aucun montant national unique à promettre.", "Frais de candidature et Master : fixés par l’établissement/programme; généralement non remboursables lorsqu’indiqués."], en: ["UBC international Bachelor 2026/27: examples of about CAD 48,780–67,237/year by programme.", "Living costs: city, housing, insurance and books vary; no single national amount should be promised.", "Application and Master fees are set by the institution/programme and are often non-refundable when stated."] },
    language: { fr: ["UBC IELTS Academic 6,5 total, aucune partie sous 6,0.", "UBC TOEFL iBT 90; PTE Academic 65; Cambridge 180; CAEL 70; DET 125.", "Ces seuils sont ceux d’UBC et ne remplacent pas la règle du programme ou du Master visé."], en: ["UBC IELTS Academic 6.5 overall, no component below 6.0.", "UBC TOEFL iBT 90; PTE Academic 65; Cambridge 180; CAEL 70; DET 125.", "These are UBC thresholds and do not replace the rule of the target programme or graduate faculty."] },
    visa: { fr: ["Permis d’études : 150 CAD; biométrie : 85 CAD, lorsque requise.", "Visa visiteur : 100 CAD; eTA : 7 CAD lorsque applicable.", "Frais annexes possibles : examen médical, certificat de police, traductions, VAC, assurance, PAL/TAL/CAQ et preuve de fonds."], en: ["Study permit: CAD 150; biometrics: CAD 85 when required.", "Visitor visa: CAD 100; eTA: CAD 7 where applicable.", "Possible extra costs: medical exam, police certificate, translations, VAC, insurance, PAL/TAL/CAQ and proof of funds."] },
    schools: { fr: ["UBC — exemples de frais et dates détaillés.", "McGill — exigences internationales et Advanced Levels.", "University of Toronto, Waterloo, Alberta — vérifier programme, frais et deadlines directement."], en: ["UBC — detailed fee and deadline examples.", "McGill — international and Advanced Levels requirements.", "University of Toronto, Waterloo, Alberta — check programme, fees and deadlines directly."] }
  },
  france: {
    calendar: { fr: ["Rentrée principale : septembre; semestre 1 à l’automne, semestre 2 au printemps, rattrapages en été.", "Parcoursup 2026 : vœux du 19 janvier au 12 mars, dossier jusqu’au 1er avril, admission principale du 2 juin au 11 juillet.", "DAP : généralement début octobre à mi-décembre; Mon Master et Études en France ont leurs propres campagnes."], en: ["Main intake: September; autumn first semester, spring second semester, summer resits.", "Parcoursup 2026: choices January 19–March 12, file until April 1, main offers June 2–July 11.", "DAP usually runs from early October to mid-December; Mon Master and Études en France have separate campaigns."] },
    admissions: { fr: ["Licence : diplôme secondaire donnant accès au supérieur, relevés et procédure Parcoursup/DAP/Études en France selon le cas.", "Master : Licence/Bachelor pertinent, relevés et prérequis de la formation; candidature via Mon Master, e-candidat ou établissement.", "Burundi/Rwanda, Cambridge, Edexcel et SAT : aucune équivalence automatique; l’établissement peut demander traductions ou comparabilité ENIC-NARIC."], en: ["Licence: secondary credential giving higher-education access, transcripts and Parcoursup/DAP/Études en France as applicable.", "Master: relevant Bachelor degree, transcripts and course prerequisites; Mon Master, e-candidat or direct application.", "Burundi/Rwanda, Cambridge, Edexcel and SAT: no automatic equivalency; translations or ENIC-NARIC comparability may be requested."] },
    costs: { fr: ["Droits publics 2026/27 : 178 EUR Licence et 255 EUR Master UE/EEE; 2 902 EUR Licence et 3 950 EUR Master hors UE, exemptions possibles.", "CVEC : exemple UGA 105 EUR en 2026/27.", "Ressources administratives étudiant : 877,50 EUR/mois; budget réel, logement et frais de candidature varient."], en: ["Public fees 2026/27: EUR 178 Licence and EUR 255 Master EU/EEA; EUR 2,902 Licence and EUR 3,950 Master non-EU, exemptions possible.", "CVEC: UGA example EUR 105 in 2026/27.", "Administrative student resources: EUR 877.50/month; actual budget, housing and application fees vary."] },
    language: { fr: ["Français : DELF, DALF, TCF ou autre test accepté selon la formation; aucun seuil national unique.", "Exemple Master UGA anglophone : niveau B2 et IELTS/TOEFL/TOEIC/CAE/CPE ou attestation d’études en anglais.", "Toujours vérifier le test, la validité et le niveau sur la fiche officielle du diplôme."], en: ["French: DELF, DALF, TCF or another accepted test depending on the course; no single national threshold.", "UGA English-taught Master example: B2 and IELTS/TOEFL/TOEIC/CAE/CPE or proof of prior English-medium study.", "Always check test, validity and level on the official degree page."] },
    visa: { fr: ["Visa long séjour étudiant EEF : 50 EUR pour pays soumis à Études en France, dont Burundi/Rwanda; autres pays 99 EUR.", "Validation VLS-TS après arrivée : taxe de 100 EUR selon Service-Public.", "Frais annexes : Campus France, centre de dépôt, biométrie, assurance, traductions/légalisation et titre de séjour selon le cas."], en: ["EEF long-stay student visa: EUR 50 for Études en France countries including Burundi/Rwanda; other countries EUR 99.", "VLS-TS validation after arrival: EUR 100 tax according to Service-Public.", "Extra costs: Campus France, visa centre, biometrics, insurance, translations/legalisation and residence permit as applicable."] },
    schools: { fr: ["Université Paris-Saclay — droits et admissions internationales.", "Université de Strasbourg — procédures internationales et tarifs.", "Université Grenoble Alpes, Sorbonne, Lyon 1 — vérifier formation et langue."], en: ["Université Paris-Saclay — international admissions and fee examples.", "University of Strasbourg — international procedures and fees.", "Université Grenoble Alpes, Sorbonne, Lyon 1 — check course and language."] }
  },
  belgique: {
    calendar: { fr: ["Calendrier : rentrée septembre; deux semestres, examens autour de janvier et juin, seconde session en août/septembre.", "UGent : dossier complet au 1er avril avec visa, 1er juin sans visa; programmes peuvent déroger.", "KU Leuven 2026/27 : cours 21 septembre, examens janvier; second semestre 8 février, examens juin."], en: ["Calendar: September intake; two semesters, exams around January and June, resits in August/September.", "UGent: complete file by April 1 with visa, June 1 without visa; programmes may differ.", "KU Leuven 2026/27: classes September 21, January exams; second semester February 8, June exams."] },
    admissions: { fr: ["Bachelor : diplôme secondaire donnant accès à l’université dans le pays d’origine, relevés et conditions du programme.", "Master : Bachelor pertinent, relevés et évaluation individuelle; certaines filières ont examen ou prérequis.", "Burundi/Rwanda, Cambridge, Edexcel et SAT : pas d’équivalence ou seuil général; légalisation/traduction et équivalence secondaire peuvent être demandées."], en: ["Bachelor: secondary credential granting university access in the country of origin, transcripts and programme conditions.", "Master: relevant Bachelor, transcripts and individual assessment; some fields require tests or prerequisites.", "Burundi/Rwanda, Cambridge, Edexcel and SAT: no general equivalency or score; legalisation/translation and secondary equivalency may be requested."] },
    costs: { fr: ["Flandre 2026/27 : repères 1 181,40 EUR UE/EEE et 5 300–12 000 EUR hors UE/EEE pour 60 ECTS.", "KU Leuven : candidature 90 EUR; tuition exacte selon programme et statut.", "Moyens administratifs 2026/27 : 1 062 EUR/mois; ce n’est pas une estimation de budget réel."], en: ["Flanders 2026/27: reference ranges EUR 1,181.40 EU/EEA and EUR 5,300–12,000 non-EU/EEA for 60 ECTS.", "KU Leuven: EUR 90 application fee; exact tuition by programme and status.", "Administrative means 2026/27: EUR 1,062/month; this is not a real-life budget estimate."] },
    language: { fr: ["UAntwerpen : IELTS 6,5 total/6,0 par partie; PTE 59; Cambridge B2 First 176.", "VUB : IELTS 6,5/6,0; Cambridge B2 First 170; les règles peuvent changer après janvier 2026.", "Néerlandais, français et anglais : niveau et test propres au programme; SAT/Edexcel ne sont pas des tests linguistiques."], en: ["UAntwerpen: IELTS 6.5 overall/6.0 each; PTE 59; Cambridge B2 First 176.", "VUB: IELTS 6.5/6.0; Cambridge B2 First 170; rules may change after January 2026.", "Dutch, French and English: level and test depend on the programme; SAT/Edexcel are not language tests."] },
    visa: { fr: ["Études de plus de 90 jours : visa national D; frais exacts à vérifier selon poste consulaire et nationalité.", "Visa court séjour C : repère 90 EUR adulte, 45 EUR enfant 6–12 ans, à confirmer avant paiement.", "Frais annexes : contribution administrative éventuelle, certificat médical, casier judiciaire, assurance, traductions/légalisation et carte communale."], en: ["Studies over 90 days: national D visa; exact fees depend on consular post and nationality.", "Short-stay C visa: reference EUR 90 adult, EUR 45 child 6–12, confirm before payment.", "Extra costs: possible administrative contribution, medical certificate, police record, insurance, translations/legalisation and municipal card."] },
    schools: { fr: ["KU Leuven — candidature, frais et tests linguistiques.", "Ghent University — deadlines et évaluation individuelle.", "University of Antwerp et VUB — conditions Bachelor/Master et anglais."], en: ["KU Leuven — application, fees and language tests.", "Ghent University — deadlines and individual assessment.", "University of Antwerp and VUB — Bachelor/Master and English conditions."] }
  },
  uk: {
    calendar: { fr: ["Rentrée principale septembre/octobre; quelques cursus commencent en janvier.", "UCAS 2026 : 15 octobre pour Oxford/Cambridge et médecine; 14 janvier pour la plupart des cursus; 30 juin avant Clearing.", "Les deadlines de bourses, tests, portfolio et CAS peuvent être antérieures."], en: ["Main intake September/October; some courses start in January.", "UCAS 2026: October 15 for Oxford/Cambridge and medicine; January 14 for most courses; June 30 before Clearing.", "Scholarship, test, portfolio and CAS deadlines may be earlier."] },
    admissions: { fr: ["Bachelor : UCAS, diplôme secondaire, notes prédites/finales, référence et exigences du cursus.", "Master : Bachelor pertinent, relevés, références, personal statement/projet et exigences du département.", "Cursus anglophone : Cambridge/Pearson Edexcel examiné selon le cursus; diplôme étranger en anglais peut nécessiter Ecctis. Aucun seuil SAT général."], en: ["Bachelor: UCAS, secondary credential, predicted/final grades, reference and course requirements.", "Master: relevant Bachelor, transcripts, references, statement/project and department requirements.", "English-medium route: Cambridge/Pearson Edexcel assessed by course; foreign English-taught degree may require Ecctis. No general SAT threshold."] },
    costs: { fr: ["Cambridge undergraduate international 2026 : 29 052–70 554 GBP/an selon cursus, College fee en plus.", "Preuve de vie UKVI : 1 529 GBP/mois Londres ou 1 171 GBP hors Londres jusqu’à 9 mois.", "Postgraduate Cambridge : candidature 20 GBP doctorat, 85 GBP autres; tuition selon cursus et statut."], en: ["Cambridge international undergraduate 2026: GBP 29,052–70,554/year by course, plus College fee.", "UKVI living funds: GBP 1,529/month London or GBP 1,171 outside London for up to 9 months.", "Cambridge postgraduate: GBP 20 doctoral application, GBP 85 other courses; tuition by course and fee status."] },
    language: { fr: ["UKVI : niveau B2 minimum pour un cursus degree-level; B1 sous le niveau degree.", "Cambridge : IELTS généralement 7,5 total, au moins 7,0 par composante; C1 Advanced 193, C2 Proficiency 200.", "Un établissement peut accepter un diplôme enseigné en anglais ou Ecctis selon les règles applicables."], en: ["UKVI: minimum B2 for degree-level study; B1 below degree level.", "Cambridge: usually IELTS 7.5 overall, at least 7.0 each; C1 Advanced 193, C2 Proficiency 200.", "An institution may accept an English-medium degree or Ecctis under applicable rules."] },
    visa: { fr: ["Student visa : 558 GBP depuis l’extérieur ou pour prolongation/changement selon GOV.UK.", "IHS étudiant : 776 GBP/an; le total dépend de la durée et peut inclure une demi-année.", "Frais annexes : TB, biométrie/centre, priority, traductions, Ecctis et ATAS si requis."], en: ["Student visa: GBP 558 from outside or for extension/change according to GOV.UK.", "Student IHS: GBP 776/year; total depends on visa length and may include a half-year.", "Extra costs: TB, biometrics/centre, priority, translations, Ecctis and ATAS where required."] },
    schools: { fr: ["University of Cambridge — frais internationaux et seuils d’anglais.", "University of Oxford — UCAS et qualifications internationales.", "UCL — frais overseas et programmes à vérifier par cursus."], en: ["University of Cambridge — international fees and English thresholds.", "University of Oxford — UCAS and international qualifications.", "UCL — overseas fees and course-specific programmes."] }
  },
  usa: {
    calendar: { fr: ["Repères : Fall août/septembre, Spring janvier, Summer mai/juin; aucun calendrier national.", "UW first-year international : exemple Autumn, deadline 15 novembre; Winter/Spring peuvent être fermés aux first-years.", "Purdue exige tous les éléments à 23 h 59 Eastern Time; bourses et I-20 peuvent avoir des délais antérieurs."], en: ["Reference intakes: Fall August/September, Spring January, Summer May/June; no national calendar.", "UW international first-year: Autumn example, November 15 deadline; Winter/Spring may be closed to first-years.", "Purdue requires all materials by 11:59 PM Eastern Time; scholarships and I-20 may close earlier."] },
    admissions: { fr: ["Bachelor : diplôme secondaire, relevés, préparation par matières et preuve d’anglais; first-year ou transfer selon le parcours.", "Master : Bachelor équivalent, relevés, CV/projet, recommandations et GRE/GMAT si le département le demande.", "Burundi/Rwanda, Cambridge, Edexcel et SAT : évalués par l’établissement; aucun seuil académique national."], en: ["Bachelor: secondary diploma, transcripts, subject preparation and English proof; first-year or transfer by background.", "Master: equivalent Bachelor, transcripts, CV/statement, recommendations and GRE/GMAT if the department requires it.", "Burundi/Rwanda, Cambridge, Edexcel and SAT: assessed by the institution; no national academic threshold."] },
    costs: { fr: ["Exemples officiels : Purdue 32 104 USD tuition/frais 2025/26; Minnesota 44 743 USD 2026/27; UW 61 052 USD/4 trimestres.", "Vie/assurance : Purdue 13 720 USD logement/nourriture; Minnesota vie 23 669 + assurance 3 590; UW vie 31 120 + assurance 2 148.", "Frais de candidature et tuition varient selon établissement, programme et crédits; vérifier les barèmes datés."], en: ["Official examples: Purdue USD 32,104 tuition/fees 2025/26; Minnesota USD 44,743 2026/27; UW USD 61,052/4 quarters.", "Living/insurance: Purdue USD 13,720 housing/food; Minnesota living 23,669 + insurance 3,590; UW living 31,120 + insurance 2,148.", "Application and tuition fees vary by institution, programme and credits; check dated schedules."] },
    language: { fr: ["Minnesota : TOEFL 4,5; IELTS 6,5; PTE 59; Cambridge 180; DET 120, selon la page undergraduate.", "Illinois transfer : TOEFL 5,0, IELTS 7,5, DET 130 selon les règles publiées après 21 janvier 2026; ce n’est pas first-year.", "SAT/ACT peut être utilisé selon l’établissement, mais n’est pas une équivalence linguistique ou académique universelle."], en: ["Minnesota: TOEFL 4.5; IELTS 6.5; PTE 59; Cambridge 180; DET 120 for undergraduate page.", "Illinois transfer: TOEFL 5.0, IELTS 7.5, DET 130 under rules after January 21, 2026; not first-year.", "SAT/ACT may be used by an institution but is not a universal language or academic equivalency."] },
    visa: { fr: ["F-1 académique et M-1 professionnel : demande de visa 185 USD.", "SEVIS I-901 : 350 USD F-1/M-1; J-1 généralement 220 USD selon catégorie.", "Frais de réciprocité, photo, DS-160, déplacement, traduction, assurance et courrier varient selon nationalité et centre."], en: ["Academic F-1 and vocational M-1: USD 185 visa application fee.", "I-901 SEVIS: USD 350 for F-1/M-1; J-1 generally USD 220 depending on category.", "Reciprocity, photo, DS-160, travel, translation, insurance and courier costs vary by nationality and centre."] },
    schools: { fr: ["University of Minnesota — coûts et seuils d’anglais détaillés.", "University of Washington — dépenses annuelles 2026/27.", "Purdue et University of Illinois — admissions internationales et exemples de règles."], en: ["University of Minnesota — detailed costs and English thresholds.", "University of Washington — 2026/27 annual expenses.", "Purdue and University of Illinois — international admissions and rule examples."] }
  },
  schengen: {
    calendar: { fr: ["Repère commun : rentrée septembre/octobre; semestre 1 automne, semestre 2 printemps, rattrapages été.", "KU Leuven 2026/27 : cours 21 septembre, second semestre 8 février; examens janvier et juin.", "UvA : Bachelors selon quota/sélection, repères 15 janvier, 1er février, 1er avril ou 1er mai; Masters par programme."], en: ["Common reference: September/October intake; autumn first semester, spring second semester, summer resits.", "KU Leuven 2026/27: classes September 21, second semester February 8; January and June exams.", "UvA: Bachelor deadlines by quota/selection, reference dates January 15, February 1, April 1 or May 1; Masters by programme."] },
    admissions: { fr: ["Bachelor : diplôme secondaire donnant accès au supérieur, relevés, langue et conditions propres au pays/établissement.", "Master : Bachelor/Licence pertinent et exigences propres au programme; admission individuelle.", "France, Allemagne, Belgique, Pays-Bas : Burundi/Rwanda, Cambridge, Edexcel, SAT et exemptions linguistiques ne sont pas automatiques."], en: ["Bachelor: secondary credential granting higher-education access, transcripts, language and country/institution conditions.", "Master: relevant Bachelor/Licence and programme-specific requirements; individual assessment.", "France, Germany, Belgium and Netherlands: Burundi/Rwanda, Cambridge, Edexcel, SAT and language exemptions are not automatic."] },
    costs: { fr: ["France hors UE : 2 902 EUR Licence et 3 950 EUR Master; exemptions possibles.", "Allemagne : coût de vie DAAD/Study in Germany environ 900–1 200 EUR/mois; logement 290–560 EUR.", "Belgique/Pays-Bas : tuition et candidatures varient; exemples KU Leuven 90 EUR et UvA Master international 100 EUR."], en: ["France non-EU: EUR 2,902 Licence and EUR 3,950 Master; exemptions possible.", "Germany: DAAD/Study in Germany living reference about EUR 900–1,200/month; housing EUR 290–560.", "Belgium/Netherlands: tuition and applications vary; KU Leuven EUR 90 and UvA international Master EUR 100 examples."] },
    language: { fr: ["KU Leuven : IELTS 6,5, TOEFL 79, Cambridge C1/C2; Duolingo non accepté selon la page consultée.", "Français, allemand et néerlandais : niveaux selon la formation et l’établissement; aucun seuil Schengen commun.", "Un cursus anglophone antérieur n’exempte que si la règle officielle du programme le prévoit."], en: ["KU Leuven: IELTS 6.5, TOEFL 79, Cambridge C1/C2; Duolingo not accepted on the consulted page.", "French, German and Dutch: levels depend on course and institution; no common Schengen threshold.", "Prior English-medium study is exempt only when the official programme rule allows it."] },
    visa: { fr: ["France : visa étudiant EEF 50 EUR, autres pays 99 EUR; validation VLS-TS et frais annexes selon situation.", "Allemagne : visa national 75 EUR; Schengen court séjour 90 EUR, enfant 45 EUR.", "Pays-Bas : permis d’études IND 254 EUR; Belgique : tarif à vérifier selon poste, nationalité et contribution éventuelle."], en: ["France: EEF student visa EUR 50, other countries EUR 99; VLS-TS validation and extras depend on case.", "Germany: national visa EUR 75; short-stay Schengen EUR 90, child EUR 45.", "Netherlands: IND study permit EUR 254; Belgium: check by post, nationality and possible contribution."] },
    schools: { fr: ["KU Leuven — Belgique, calendrier, frais de candidature et tests.", "University of Amsterdam — Pays-Bas, deadlines Bachelor et frais Master.", "Universität Heidelberg — Allemagne; France : Paris-Saclay, Strasbourg, Grenoble Alpes."], en: ["KU Leuven — Belgium, calendar, application fee and tests.", "University of Amsterdam — Netherlands, Bachelor deadlines and Master fee.", "Heidelberg University — Germany; France: Paris-Saclay, Strasbourg, Grenoble Alpes."] }
  }
};

const categoryFeeDetails: Record<CountryKey, ResearchField[]> = {
  canada: [
    { fr: ["Visa visiteur : 100 CAD; eTA 7 CAD selon nationalité. Biométrie 85 CAD si requise.", "Démarches : formulaire, motif, fonds, attaches, hébergement/itinéraire et biométrie si demandée."], en: ["Visitor visa: CAD 100; eTA CAD 7 depending on nationality. Biometrics CAD 85 when required.", "Process: form, purpose, funds, ties, accommodation/itinerary and biometrics when requested."] },
    { fr: ["Permis d’études : 150 CAD; biométrie 85 CAD si requise. PAL/TAL ou CAQ peuvent s’appliquer.", "Démarches : admission DLI, lettre d’acceptation, preuves financières, demande en ligne et suivi."], en: ["Study permit: CAD 150; biometrics CAD 85 when required. PAL/TAL or CAQ may apply.", "Process: DLI admission, letter of acceptance, funds evidence, online application and tracking."] },
    { fr: ["Permis de travail : 155 CAD; permis ouvert ajoute généralement 100 CAD; biométrie 85 CAD si requise.", "Démarches : offre/LMIA ou exemption, documents employeur, admissibilité et examen médical si requis."], en: ["Work permit: CAD 155; open work permit generally adds CAD 100; biometrics CAD 85 when required.", "Process: offer/LMIA or exemption, employer documents, admissibility and medical exam when required."] },
    { fr: ["Entrée express / RP : traitement 950 CAD + droit de résidence permanente 575 CAD; biométrie 85 CAD.", "Démarches : profil, bassin, invitation, certificats de police, examen médical, preuves d’expérience et fonds."], en: ["Express Entry / PR: CAD 950 processing + CAD 575 right of permanent residence; biometrics CAD 85.", "Process: profile, pool, invitation, police certificates, medical exam, experience and funds evidence."] },
  ],
  schengen: [
    { fr: ["Tourisme Type C : 90 EUR adulte; 45 EUR enfant 6–12 ans. Assurance et centre de dépôt en plus.", "Démarches : consulat du pays principal, formulaire, réservations, fonds, assurance, biométrie et décision."], en: ["Type C tourism: EUR 90 adult; EUR 45 child 6–12. Insurance and visa centre extra.", "Process: main-destination consulate, form, bookings, funds, insurance, biometrics and decision."] },
    { fr: ["Affaires Type C : même barème Schengen de référence; lettre d’invitation et frais de service peuvent s’ajouter.", "Démarches : invitation professionnelle, attestation d’emploi, itinéraire, ressources et assurance."], en: ["Type C business: same Schengen reference fee; invitation and service fees may be extra.", "Process: business invitation, employment letter, itinerary, funds and insurance."] },
    { fr: ["Visite familiale Type C : 90 EUR adulte; frais de centre, assurance et traduction éventuels en plus.", "Démarches : invitation, preuve du lien familial, hébergement, ressources et intention de retour."], en: ["Type C family visit: EUR 90 adult; centre, insurance and translation fees may be extra.", "Process: invitation, relationship proof, accommodation, funds and return intention."] },
    { fr: ["Transit / médical : frais selon le Type C ou la règle nationale; traitements et services médicaux restent séparés.", "Démarches : itinéraire complet ou lettre médicale, assurance et justificatifs du pays de destination."], en: ["Transit / medical: fee follows the Type C or national rule; treatment and medical services are separate.", "Process: full itinerary or medical letter, insurance and destination-country evidence."] },
  ],
  france: [
    { fr: ["Étudiant long séjour : 50 EUR via EEF pour les pays concernés, sinon 99 EUR; validation VLS-TS 100 EUR selon cas.", "Démarches : admission, Études en France si requise, ressources, logement, visa wizard et formalités à l’arrivée."], en: ["Long-stay student: EUR 50 via EEF for covered countries, otherwise EUR 99; VLS-TS validation EUR 100 as applicable.", "Process: admission, Études en France when required, funds, housing, visa wizard and arrival formalities."] },
    { fr: ["Étudiant-concours : frais du visa court séjour selon barème Schengen; convocation obligatoire.", "Démarches : convocation, dossier financier et académique, rendez-vous, biométrie et retour si aucun droit au séjour."], en: ["Student examination: short-stay fee under the Schengen schedule; examination summons required.", "Process: summons, financial and academic file, appointment, biometrics and departure if no residence right."] },
    { fr: ["Visiteur : long séjour généralement 99 EUR; court séjour 90 EUR adulte, hors frais de centre et services.", "Démarches : motif, ressources, hébergement, assurance, preuves de retour et demande France-Visas."], en: ["Visitor: long-stay generally EUR 99; short-stay EUR 90 adult, excluding centre and service fees.", "Process: purpose, funds, accommodation, insurance, return evidence and France-Visas application."] },
  ],
  belgique: [
    { fr: ["Étudiant Visa D : 180 EUR; contribution administrative éventuelle, certificat médical et carte communale en plus.", "Démarches : admission, moyens de subsistance, assurance, logement, dépôt consulaire et inscription à l’arrivée."], en: ["Student Visa D: EUR 180; possible administrative contribution, medical certificate and municipal card extra.", "Process: admission, means, insurance, housing, consular filing and registration after arrival."] },
    { fr: ["Schengen visite Type C : 90 EUR adulte; 45 EUR enfant 6–12 ans, hors centre et assurance.", "Démarches : consulat compétent, invitation/hébergement, fonds, assurance, biométrie et suivi."], en: ["Type C Schengen visit: EUR 90 adult; EUR 45 child 6–12, excluding centre and insurance.", "Process: competent consulate, invitation/accommodation, funds, insurance, biometrics and tracking."] },
    { fr: ["Admissions : pas de visa propre; après admission, appliquer le Visa D avec les frais et contributions correspondants.", "Démarches : candidature, équivalence/traductions si demandées, admission, preuve de moyens puis visa."], en: ["Admissions: no separate visa; after admission, apply for Visa D with corresponding fees and contributions.", "Process: application, equivalency/translations when requested, admission, funds and visa."] },
  ],
  uk: [
    { fr: ["Student visa : 558 GBP selon GOV.UK; IHS étudiant généralement 776 GBP/an; biométrie et services priority en plus.", "Démarches : offre, CAS, fonds, anglais, demande en ligne, biométrie et eVisa."], en: ["Student visa: GBP 558 according to GOV.UK; student IHS generally GBP 776/year; biometrics and priority services extra.", "Process: offer, CAS, funds, English, online application, biometrics and eVisa."] },
    { fr: ["Visitor : repère 127 GBP; biométrie, traductions et services optionnels peuvent s’ajouter.", "Démarches : formulaire, motif, fonds, itinéraire, attaches, rendez-vous et biométrie."], en: ["Visitor: GBP 127 reference; biometrics, translations and optional services may be extra.", "Process: form, purpose, funds, itinerary, ties, appointment and biometrics."] },
    { fr: ["Admissions : frais de visa non applicables avant admission; UCAS et établissements fixent leurs propres frais.", "Démarches : candidature, offre, conditions, dépôt éventuel, CAS si études puis Student visa."], en: ["Admissions: no visa fee before admission; UCAS and institutions set their own fees.", "Process: application, offer, conditions, possible deposit, CAS for study and Student visa."] },
  ],
  usa: [
    { fr: ["Visiteur B-1/B-2 : 185 USD non remboursables; éventuels frais de réciprocité selon nationalité.", "Démarches : DS-160, paiement, rendez-vous, entretien; démontrer motif temporaire, fonds, attaches et intention de départ."], en: ["B-1/B-2 visitor: non-refundable USD 185; possible reciprocity fee by nationality.", "Process: DS-160, payment, appointment and interview; show temporary purpose, funds, ties and intent to depart."] },
    { fr: ["F/M études : 185 USD + SEVIS I-901 350 USD; J-1 : SEVIS selon catégorie.", "Démarches : admission SEVP, I-20/DS-2019, SEVIS, DS-160, entretien et preuve financière."], en: ["F/M study: USD 185 + USD 350 I-901 SEVIS; J-1 SEVIS varies by category.", "Process: SEVP admission, I-20/DS-2019, SEVIS, DS-160, interview and funds evidence."] },
    { fr: ["Travail H/L/O/P/Q/R : base consulaire 205 USD; pétition USCIS et frais additionnels éventuels. E 315 USD, K 265 USD.", "Démarches : employeur/sponsor, pétition ou preuve d’éligibilité, DS-160, entretien et réciprocité si applicable."], en: ["H/L/O/P/Q/R work: USD 205 consular base; USCIS petition and possible extra fees. E USD 315, K USD 265.", "Process: employer/sponsor, petition or eligibility proof, DS-160, interview and reciprocity if applicable."] },
  ],
};

const financialEvidenceByCountry: Record<CountryKey, ResearchField> = {
  canada: { fr: ["Visite : relevés bancaires récents, attestation d’emploi et congé, fiches de paie, preuve de logement et invitation/prise en charge si applicable.", "Études : relevés sur plusieurs mois, lettre de banque, prêt ou bourse, reçu de tuition, preuve de logement et fonds pour les frais de vie; PAL/TAL ou CAQ ne remplacent pas la preuve financière.", "Travail / Entrée express : contrat ou offre, fiches de paie, épargne et fonds d’établissement; expliquer clairement l’origine des fonds. Les montants dépendent de la catégorie et de la composition familiale."], en: ["Visit: recent bank statements, employment and leave letter, payslips, accommodation proof and invitation/sponsorship where applicable.", "Study: statements covering several months, bank letter, loan or scholarship, tuition receipt, housing and living-funds evidence; PAL/TAL or CAQ do not replace financial proof.", "Work / Express Entry: contract or offer, payslips, savings and settlement funds; clearly explain the source of funds. Amounts depend on route and family size."] },
  schengen: { fr: ["Tourisme/affaires : relevés bancaires récents, fiches de paie, attestation de travail, congé, réservation et assurance; l’hôte peut joindre prise en charge selon le pays.", "Visite familiale : invitation, identité et domicile de l’hôte, preuve de lien, hébergement et ressources du demandeur et/ou du garant.", "Transit/médical : itinéraire, billets ou réservation, devis/lettre médicale, assurance et preuve de paiement ou de prise en charge."], en: ["Tourism/business: recent bank statements, payslips, employment letter, leave, booking and insurance; host sponsorship may be added by country.", "Family visit: invitation, host identity/address, relationship proof, accommodation and applicant and/or sponsor funds.", "Transit/medical: itinerary, tickets or booking, medical letter/estimate, insurance and payment or sponsorship proof."] },
  france: { fr: ["Visiteur : relevés bancaires, ressources régulières, attestation d’emploi, hébergement et prise en charge si un tiers paie; les ressources doivent couvrir le séjour.", "Étudiant : justificatif de bourse, virement familial documenté, relevés, attestation de prise en charge, logement et ressources demandées par France-Visas/Campus France.", "Documents acceptés en pratique : originaux bancaires, lettres signées et datées, contrats de travail, fiches de paie; traductions officielles si exigées."], en: ["Visitor: bank statements, regular income, employment letter, accommodation and third-party sponsorship when someone else pays; resources should cover the stay.", "Student: scholarship proof, documented family transfer, statements, sponsorship letter, housing and resources requested by France-Visas/Campus France.", "Common evidence: original bank records, signed and dated letters, employment contracts and payslips; official translations when required."] },
  belgique: { fr: ["Visite Type C : relevés, revenus, emploi, hébergement et engagement de prise en charge si applicable; assurance voyage séparée.", "Étudiant Visa D : attestation de bourse ou garant, preuve de moyens de subsistance, logement et assurance; le montant est actualisé par l’autorité.", "Travail/famille : contrat ou revenus du garant, fiches de paie, relevés, logement et preuve du lien; contribution administrative distincte."], en: ["Type C visit: statements, income, employment, accommodation and sponsorship undertaking where applicable; travel insurance is separate.", "Student Visa D: scholarship or guarantor letter, means of subsistence, housing and insurance; the authority updates the required amount.", "Work/family: contract or sponsor income, payslips, statements, housing and relationship proof; administrative contribution is separate."] },
  uk: { fr: ["Visitor : relevés et revenus couvrant le séjour, emploi/congé, hébergement, itinéraire et preuve de prise en charge si un tiers finance.", "Student : relevés détenus pendant la période requise par UKVI, prêt/bourse, CAS, tuition payée et fonds de vie Londres ou hors Londres selon la règle en vigueur.", "Travail/famille : salaire, contrat, sponsor agréé, relevés et logement; les documents doivent être cohérents avec le formulaire et la source des fonds."], en: ["Visitor: statements and income covering the stay, employment/leave, accommodation, itinerary and sponsorship proof if a third party pays.", "Student: statements held for the period required by UKVI, loan/scholarship, CAS, paid tuition and London or outside-London living funds under current rules.", "Work/family: salary, contract, licensed sponsor, statements and housing; documents must match the form and source of funds."] },
  usa: { fr: ["Visiteur B-1/B-2 : relevés, fiches de paie, emploi, propriété ou famille à charge pour démontrer ressources et attaches; invitation seule insuffisante.", "F/M/J : preuve de paiement SEVIS, I-20/DS-2019, relevés, bourse, prêt ou sponsor documenté; le financement doit couvrir études et séjour.", "Travail : contrat/offre, pétition ou sponsor, salaire et pièces de l’employeur; pour tout tiers payeur, joindre lettre et preuve de capacité financière."], en: ["B-1/B-2 visitor: statements, payslips, employment, property or dependent-family evidence to show funds and ties; invitation alone is insufficient.", "F/M/J: SEVIS receipt, I-20/DS-2019, statements, scholarship, loan or documented sponsor; funding should cover study and stay.", "Work: contract/offer, petition or sponsor, salary and employer documents; for third-party funding, add a letter and capacity proof."] },
};

const categoryProcessingTimes: Record<CountryKey, string[]> = {
  canada: ["Visiteur : souvent plusieurs semaines; permis d’études/travail et Entrée express varient selon le bureau, la biométrie et la complétude.", "Études : délai variable après biométrie et réception des pièces; PAL/TAL, CAQ ou examen médical peuvent prolonger le traitement.", "Travail : variable selon permis, EIMT/exemption et pays de dépôt; ne pas réserver sur la seule base d’un délai estimé.", "Entrée express / RP : après invitation, le délai dépend du programme, des vérifications et de la complétude du dossier."],
  schengen: ["Tourisme : décision généralement dans le délai consulaire standard, mais prolongations possibles pour contrôles ou pièces supplémentaires.", "Affaires : délai variable selon consulat, invitation et vérifications; déposer suffisamment tôt.", "Visite familiale : délai variable selon représentation et complétude; l’invitation ne garantit pas l’issue.", "Transit / médical : urgence ou traitement ne supprime pas les contrôles; vérifier le poste compétent avant dépôt."],
  france: ["Étudiant long séjour : délai variable après Campus France/visa; la saison et les pièces manquantes peuvent allonger l’attente.", "Étudiant-concours : dépend du rendez-vous, de la convocation et de la période; prévoir une marge avant l’examen.", "Visiteur : court et long séjour varient selon centre, saison et vérifications; suivre France-Visas."],
  belgique: ["Étudiant Visa D : délai variable selon poste, admission, contribution et vérifications; prévoir une marge avant la rentrée.", "Schengen visite : délai variable selon consulat et saison; pièces supplémentaires possibles.", "Admissions : le délai dépend de l’établissement; après admission, le Visa D a son propre délai administratif."],
  uk: ["Student visa : le délai standard dépend du pays et du service choisi; CAS, biométrie ou contrôles peuvent le prolonger.", "Visitor : délai variable selon pays, saison et service; ne pas acheter de billet non remboursable avant décision.", "Admissions : UCAS/établissement et visa ont des délais distincts; le CAS doit être émis avant la demande étudiant."],
  usa: ["Visiteur B-1/B-2 : dépend du calendrier des rendez-vous, du poste consulaire et d’un éventuel traitement administratif.", "F/M études : dépend de l’admission, du rendez-vous, de l’entretien et d’un éventuel traitement administratif; anticiper la rentrée.", "Travail H/L/O/P/Q/R : pétition USCIS et entretien consulaire ont des délais distincts; premium processing éventuel selon éligibilité."],
};

const copy = { fr: { nav: ["Services", "Parcours", "Guides pays", "Accompagnement", "À propos"],
    heroEyebrow: "NZO TRAVEL AGENCY · BURUNDI / INTERNATIONAL",
    heroTitle: "Votre prochaine frontière mérite un plan.",
    heroBody: "Voyage, études et projets d’immigration : nous transformons des démarches complexes en un parcours clair, documenté et humain.",
    primary: "Parler à un consultant",
    secondary: "Explorer les destinations",
    trust: "Accompagnement stratégique · Dossiers structurés · Sources officielles",
    welcome: "Bienvenue chez NZO",
    introTitle: "Un bureau de parcours, pas une promesse de visa.",
    introBody: "NZO Travel Agency accompagne les candidats, étudiants, familles et voyageurs dans la préparation de leurs projets internationaux. Notre rôle : comprendre votre objectif, vérifier les conditions applicables et vous aider à déposer un dossier cohérent.",
    servicesTitle: "Un accompagnement de bout en bout",
    servicesBody: "Du premier diagnostic jusqu’au suivi du dossier, chaque étape est pensée pour réduire les oublis et clarifier les décisions.",
    services: [
      { title: "Résidence temporaire", body: "Visite, études, travail, mobilité et regroupement selon les règles du pays visé.", icon: Plane },
      { title: "Entrée express", body: "Profil, admissibilité, score, pièces justificatives et préparation à l’invitation.", icon: Route },
      { title: "Admissions internationales", body: "Choix de programme, candidature, inscription et cohérence du projet académique.", icon: GraduationCap },
    ],
    pathTitle: "Un chemin lisible, à votre rythme",
    pathBody: "Chaque projet commence par une lecture réaliste de votre situation. Pas de raccourci magique : une méthode, des preuves et des prochaines étapes concrètes.",
    steps: ["Diagnostic initial", "Stratégie & admissibilité", "Documents & formulaires", "Dépôt & suivi"],
    guideEyebrow: "GUIDES PAYS & CATÉGORIES",
    guideTitle: "Le bon pays. La bonne catégorie. Le bon dossier.",
    guideBody: "Sélectionnez une destination pour afficher les principales voies, les points d’admissibilité et la checklist documentaire de départ.",
    eligibility: "Admissibilité",
    documents: "Documents de départ",
    process: "Parcours indicatif",
    admissions: "Admissions & inscriptions",
    official: "Vérifier sur le site officiel",
    sourceNote: "Les règles évoluent. Cette synthèse oriente votre préparation et ne remplace pas les instructions officielles.",
    checklistTitle: "Checklist universelle",
    checklistBody: "Les pièces exactes varient selon la nationalité, la catégorie, l’établissement et le bureau compétent. Préparez vos originaux et traductions lorsque requis.",
    checklist: ["Passeport valide et historique de voyages", "État civil : acte de naissance, mariage, personnes à charge", "Preuves financières et origine des fonds", "Diplômes, relevés, attestations d’emploi et CV", "Preuves linguistiques selon le programme", "Lettre d’admission, invitation ou itinéraire", "Certificats de police, biométrie ou examen médical si requis"],
    expertEyebrow: "LE CONSULTANT EXPERT",
    expertTitle: "Alex Irakoze",
    expertBody: "Alex Irakoze est le consultant expert de NZO Travel Agency, avec une expérience en conseil stratégique dans les domaines du voyage et de la technologie. Pour en savoir plus sur son parcours et échanger sur votre projet, consultez son profil LinkedIn.",
    viewLinkedin: "Voir le profil LinkedIn",
    supportEyebrow: "ACCOMPAGNEMENT & FORFAITS",
    supportTitle: "Une première analyse claire, avant d’aller plus loin.",
    supportBody: "Chaque dossier commence par un accueil, une analyse personnalisée et une étude de faisabilité. Le reste de l’accompagnement est défini après la signature du contrat, selon la nature et la complexité de votre projet.",
    initialLabel: "Forfait initial",
    initialPrice: "300 USD",
    initialBody: "Accueil du client, analyse de sa situation et étude de faisabilité du projet.",
    initialNote: "Non remboursable. À régler avant la signature du contrat et la soumission du dossier.",
    tailoredLabel: "Accompagnement sur mesure",
    tailoredPrice: "Après contrat",
    tailoredBody: "Préparation, formulaires, stratégie documentaire, admissions, soumission et suivi selon le cas.",
    tailoredNote: "Les honoraires sont discutés après signature du contrat et adaptés à chaque dossier.",
    supportDisclaimer: "Les cas ne sont pas identiques et ne se traitent pas de la même manière. NZO Travel Agency accompagne et conseille, sans garantir l’obtention d’un visa ou d’une admission.",
    contactTitle: "Parlons de votre projet",
    contactBody: "Décrivez votre destination, votre niveau d’études ou votre situation familiale. Nous vous indiquerons les premières pièces à réunir.",
    whatsapp: "Écrire sur WhatsApp",
    email: "Envoyer les documents",
    disclaimerTitle: "Notre cadre d’intervention",
    disclaimer: "NZO Travel Agency accompagne et conseille. Nous ne garantissons jamais l’obtention d’un visa, d’une admission ou d’un permis. Nous ne sommes pas un service gouvernemental et ne travaillons pas pour les gouvernements. La décision finale appartient exclusivement à l’autorité compétente ou à l’établissement concerné.",
    footer: "NZO Travel Agency · Travel, admissions & immigration projects",
    officialSources: "Sources officielles consultées",
    scrollTop: "Retour en haut",
    language: "Langue",
  },
  en: {
    nav: ["Services", "Pathway", "Country guides", "Support", "About"],
    heroEyebrow: "NZO TRAVEL AGENCY · BURUNDI / INTERNATIONAL",
    heroTitle: "Your next border deserves a plan.",
    heroBody: "Travel, education and immigration projects: we turn complex procedures into a clear, documented and human pathway.",
    primary: "Talk to a consultant",
    secondary: "Explore destinations",
    trust: "Strategic guidance · Structured files · Official sources",
    welcome: "Welcome to NZO",
    introTitle: "A pathway desk, not a visa promise.",
    introBody: "NZO Travel Agency supports candidates, students, families and travellers preparing international projects. Our role: understand your goal, check the applicable conditions and help you submit a coherent file.",
    servicesTitle: "End-to-end guidance",
    servicesBody: "From the first assessment to file follow-up, every step is designed to reduce omissions and clarify decisions.",
    services: [
      { title: "Temporary residence", body: "Visits, study, work, mobility and family routes depending on the destination.", icon: Plane },
      { title: "Express Entry", body: "Profile, eligibility, score, supporting documents and invitation readiness.", icon: Route },
      { title: "International admissions", body: "Programme choice, application, enrolment and academic project coherence.", icon: GraduationCap },
    ],
    pathTitle: "A clear path, at your pace",
    pathBody: "Every project starts with a realistic reading of your situation. No magic shortcut: a method, evidence and concrete next steps.",
    steps: ["Initial assessment", "Strategy & eligibility", "Documents & forms", "Submission & follow-up"],
    guideEyebrow: "COUNTRY & CATEGORY GUIDES",
    guideTitle: "The right country. The right category. The right file.",
    guideBody: "Select a destination to display its main routes, eligibility points and starting document checklist.",
    eligibility: "Eligibility",
    documents: "Starting documents",
    process: "Indicative pathway",
    admissions: "Admissions & enrolment",
    official: "Check the official website",
    sourceNote: "Rules change. This summary helps you prepare and does not replace official instructions.",
    checklistTitle: "Universal checklist",
    checklistBody: "Exact requirements vary by nationality, category, institution and responsible office. Prepare originals and translations where required.",
    checklist: ["Valid passport and travel history", "Civil status: birth, marriage and dependants documents", "Financial proof and source of funds", "Diplomas, transcripts, employment letters and CV", "Language evidence depending on the programme", "Admission letter, invitation or itinerary", "Police certificates, biometrics or medical exam if required"],
    expertEyebrow: "THE EXPERT CONSULTANT",
    expertTitle: "Alex Irakoze",
    expertBody: "Alex Irakoze is the expert consultant at NZO Travel Agency, with experience in strategic advisory across travel and technology. Explore his LinkedIn profile to learn more about his background and discuss your project with the agency.",
    viewLinkedin: "View LinkedIn profile",
    supportEyebrow: "SUPPORT & FEES",
    supportTitle: "A clear first assessment before going further.",
    supportBody: "Every case starts with an intake, a tailored analysis and a feasibility assessment. The remaining support is defined after the contract is signed, according to the nature and complexity of your project.",
    initialLabel: "Initial assessment",
    initialPrice: "USD 300",
    initialBody: "Client intake, situation analysis and feasibility assessment of the project.",
    initialNote: "Non-refundable. Payable before the contract is signed and the file is submitted.",
    tailoredLabel: "Tailored support",
    tailoredPrice: "After contract",
    tailoredBody: "Preparation, forms, document strategy, admissions, submission and follow-up according to the case.",
    tailoredNote: "Fees are discussed after the contract is signed and adapted to each file.",
    supportDisclaimer: "Cases are not identical and are not handled in the same way. NZO Travel Agency provides guidance and support without guaranteeing a visa or admission.",
    contactTitle: "Let’s talk about your project",
    contactBody: "Tell us your destination, study level or family situation. We will indicate the first documents to gather.",
    whatsapp: "Write on WhatsApp",
    email: "Send documents",
    disclaimerTitle: "Our scope of work",
    disclaimer: "NZO Travel Agency provides guidance and support. We never guarantee the approval of a visa, admission or permit. We are not a government service and do not work for governments. The final decision belongs exclusively to the competent authority or institution.",
    footer: "NZO Travel Agency · Travel, admissions & immigration projects",
    officialSources: "Official sources consulted",
    scrollTop: "Back to top",
    language: "Language",
  },
};

const guides: Record<Lang, Record<CountryKey, Guide>> = {
  fr: {
    canada: {
      label: "Canada",
      kicker: "Résidence temporaire & résidence permanente",
      intro: "Préparer une visite, des études, un emploi ou un profil de travailleurs qualifiés avec les formulaires et preuves adaptés.",
      categories: [
        { name: "Visite", tag: "Visiteur / eTA", icon: Plane, eligibility: ["Passeport valide et document d’entrée adapté à votre nationalité", "Motif de voyage crédible, fonds suffisants et intention de quitter le Canada", "Admissibilité générale : sécurité, santé et antécédents"], documents: ["Passeport, formulaire et photo", "Relevés bancaires, emploi et congés", "Itinéraire, hébergement et lettre d’invitation si applicable"], process: ["Déterminer visa visiteur ou eTA", "Préparer les preuves de liens et de fonds", "Soumettre en ligne et donner la biométrie si demandée"] },
        { name: "Études", tag: "Permis d’études", icon: GraduationCap, eligibility: ["Lettre d’acceptation d’un établissement d’enseignement désigné (EED/DLI)", "PAL/TAL lorsque requis, sauf exception applicable", "Démontrer les fonds, le projet d’études et la capacité à respecter les conditions"], documents: ["Lettre d’acceptation et PAL/TAL", "Passeport, formulaires, photo et biométrie", "Preuves financières, lettre d’explication et documents académiques"], process: ["Choisir un programme et obtenir l’admission", "Réunir PAL/TAL et preuves financières", "Déposer en ligne avant le départ et suivre la décision"] },
        { name: "Travail", tag: "Permis ouvert / lié", icon: BriefcaseBusiness, eligibility: ["Offre, employeur ou situation donnant accès à la catégorie visée", "Respect des conditions propres au permis ouvert ou lié à un employeur", "Admissibilité générale et, selon le cas, examen médical ou biométrie"], documents: ["Passeport et formulaires", "Offre d’emploi, contrat, LMIA ou preuve d’exemption si applicable", "CV, diplômes, preuves d’expérience et fonds"], process: ["Identifier la catégorie de permis", "Valider l’employeur et les exigences", "Déposer la demande et attendre les instructions"] },
        { name: "Entrée express", tag: "RP · travailleurs qualifiés", icon: Route, eligibility: ["Trois programmes : CEC, Federal Skilled Worker et Federal Skilled Trades", "Profil, expérience, études et langue évalués selon les règles du programme", "Entrer dans le bassin puis recevoir une invitation selon le score et le type de ronde"], documents: ["Test de langue et évaluation des diplômes", "Lettres d’emploi, passeports et preuves d’expérience", "Fonds d’établissement, certificats de police et examens si requis"], process: ["Créer le profil et entrer dans le bassin", "Surveiller le score et les rondes", "Après invitation : formulaire complet, pièces et frais"] },
      ],
      admissions: ["Choix d’un établissement et d’un programme", "Vérification des conditions d’admission et des échéances", "Candidature, lettre d’acceptation et inscription", "Préparation du permis d’études et de l’arrivée"],
      official: "https://www.canada.ca/en/immigration-refugees-citizenship.html",
    },
    schengen: {
      label: "Schengen",
      kicker: "Visas court séjour · jusqu’à 90 jours / 180",
      intro: "Un cadre commun pour les courts séjours dans l’espace Schengen : le consulat compétent dépend notamment de la destination principale.",
      categories: [
        { name: "Tourisme", tag: "Type C", icon: Plane, eligibility: ["Séjour de maximum 90 jours sur toute période de 180 jours", "Destination principale et motif cohérents", "Preuves de moyens, d’hébergement et de retour"], documents: ["Passeport, formulaire, photo et assurance voyage", "Réservations ou itinéraire et hébergement", "Relevés bancaires, emploi et preuves de liens"], process: ["Identifier le consulat du pays principal", "Prendre rendez-vous et préparer le dossier", "Biométrie, décision puis voyage selon la validité"] },
        { name: "Affaires", tag: "Type C", icon: BriefcaseBusiness, eligibility: ["Invitation ou motif professionnel vérifiable", "Séjour conforme au caractère temporaire du visa", "Ressources et itinéraire documentés"], documents: ["Lettre d’invitation de l’entreprise", "Attestation d’emploi et prise en charge", "Réservations, assurance et justificatifs financiers"], process: ["Clarifier le motif et le pays principal", "Préparer les lettres des deux parties", "Déposer auprès du prestataire compétent"] },
        { name: "Visite familiale", tag: "Type C", icon: UsersRound, eligibility: ["Lien familial et objectif du séjour documentés", "Hébergement ou prise en charge justifiée", "Intention de retour et moyens suffisants"], documents: ["Invitation, preuve de lien et identité de l’hôte", "Preuves d’emploi, ressources et domicile", "Assurance médicale de voyage et réservations"], process: ["Constituer la preuve du lien", "Vérifier la liste du consulat", "Rendez-vous, biométrie et suivi"] },
        { name: "Transit / médical", tag: "Cas spécifiques", icon: Stethoscope, eligibility: ["Catégorie adaptée au trajet ou au traitement envisagé", "Justificatifs de transit ou de prise en charge médicale", "Respect des règles nationales additionnelles"], documents: ["Itinéraire complet et visas de destination finale", "Lettre de l’hôpital ou preuve du rendez-vous", "Assurance et preuves financières"], process: ["Vérifier si un visa de transit est nécessaire", "Obtenir les justificatifs de l’établissement", "Soumettre au poste compétent"] },
      ],
      admissions: ["Pour les séjours de plus de 90 jours, les procédures sont nationales", "Pour les études, distinguer court séjour et visa long séjour du pays concerné", "Vérifier la représentation compétente avant toute réservation définitive"],
      official: "https://home-affairs.ec.europa.eu/policies/schengen-borders-and-visa/visa-policy_en",
    },
    france: {
      label: "France",
      kicker: "Études, court séjour & mobilité",
      intro: "Un parcours qui combine admission, Études en France lorsque requis et demande de visa selon la durée et la nature du projet.",
      categories: [
        { name: "Étudiant long séjour", tag: "VLS-TS", icon: GraduationCap, eligibility: ["Avoir choisi une formation et être accepté par un établissement supérieur", "Suivre Études en France si votre pays est couvert par la procédure", "Pour une formation de plus de trois mois : visa long séjour avec formalités à l’arrivée"], documents: ["Attestation d’inscription ou d’admission", "Passeport, formulaire et justificatifs demandés par le visa wizard", "Ressources, logement et parcours académique"], process: ["Candidater à l’établissement / Campus France", "Obtenir l’admission et préparer le dossier consulaire", "Déposer, puis valider le visa après l’arrivée si nécessaire"] },
        { name: "Étudiant-concours", tag: "Court séjour · 90 jours max", icon: ClipboardList, eligibility: ["Être convoqué à un concours ou examen d’entrée en France", "Démontrer le sérieux et la cohérence du projet d’études", "Si admis, régularisation possible selon les conditions applicables"], documents: ["Invitation ou convocation au concours", "Preuves du parcours et du sérieux des études", "Pièces personnelles et financières du visa wizard"], process: ["Obtenir la convocation", "Demander le visa court séjour adapté", "Quitter l’espace Schengen si l’admission n’ouvre pas de droit au séjour"] },
        { name: "Visiteur", tag: "Court / long séjour", icon: MapPin, eligibility: ["Séjour sans activité professionnelle en France", "Ressources et hébergement démontrés", "Respect de la durée autorisée par le visa"], documents: ["Passeport, assurance et formulaire", "Hébergement, ressources et motif", "Preuves de retour et attaches dans le pays de résidence"], process: ["Utiliser le visa wizard", "Prendre rendez-vous auprès du centre compétent", "Suivre la décision et les formalités d’arrivée"] },
      ],
      admissions: ["Identifier le diplôme et l’établissement", "Vérifier Parcoursup, Études en France ou la procédure propre à l’établissement", "Déposer la candidature et respecter les calendriers", "Après admission : visa et inscription administrative"],
      official: "https://france-visas.gouv.fr/en/etudiant",
    },
    belgique: {
      label: "Belgique",
      kicker: "Études & visas Schengen",
      intro: "Un accompagnement pour articuler admission dans un établissement belge, preuve de moyens et demande de visa adaptée.",
      categories: [
        { name: "Étudiant", tag: "Visa D", icon: GraduationCap, eligibility: ["Admission ou inscription dans un établissement reconnu", "Projet d’études cohérent avec le parcours antérieur", "Moyens de subsistance, assurance et conditions administratives satisfaits"], documents: ["Lettre d’admission / inscription", "Passeport, formulaire et photo", "Preuves de moyens, assurance, logement et documents académiques"], process: ["Candidater à l’établissement", "Obtenir l’inscription et réunir les preuves", "Déposer le visa long séjour puis s’inscrire à l’arrivée"] },
        { name: "Schengen visite", tag: "Type C", icon: Plane, eligibility: ["Court séjour dans la limite 90/180", "Motif principal en Belgique ou destination principale cohérente", "Hébergement, moyens et intention de retour"], documents: ["Passeport, formulaire, photo et assurance", "Invitation ou réservation d’hébergement", "Relevés bancaires, emploi et itinéraire"], process: ["Vérifier le consulat compétent", "Prendre rendez-vous et biométrie", "Voyager selon la décision et la durée accordée"] },
        { name: "Admissions", tag: "Bachelier · Master · Doctorat", icon: BookOpen, eligibility: ["Diplôme antérieur compatible et niveau linguistique demandé", "Respect des calendriers et des critères de l’établissement", "Budget d’études et projet académique réalistes"], documents: ["Diplômes et relevés certifiés", "CV, lettre de motivation et preuve de langue", "Passeport et pièces complémentaires de l’établissement"], process: ["Comparer les programmes", "Déposer la candidature", "Confirmer l’inscription et préparer la demande de visa"] },
      ],
      admissions: ["Sélectionner les établissements et vérifier la reconnaissance du diplôme", "Préparer les traductions et légalisation si demandées", "Candidater selon les calendriers de l’université ou de la haute école", "Après admission : visa D, logement, assurance et inscription"],
      official: "https://dofi.ibz.be/en/themes/third-country-nationals/study",
    },
    uk: {
      label: "Angleterre / UK",
      kicker: "Student visa & admissions",
      intro: "Un parcours conçu autour de l’admission, du CAS et des preuves exigées par UKVI pour étudier au Royaume-Uni.",
      categories: [
        { name: "Student visa", tag: "16+ · UKVI", icon: GraduationCap, eligibility: ["Avoir une place sur un cours auprès d’un sponsor étudiant agréé", "Avoir les fonds requis et prouver son niveau d’anglais", "Consentement parental requis pour certains candidats de 16–17 ans"], documents: ["CAS, passeport et preuve d’identité", "Preuves financières et anglais", "ATAS, test TB ou documents académiques si requis"], process: ["Candidater et recevoir une offre", "Accepter l’offre, obtenir le CAS", "Demander le visa en ligne et suivre l’eVisa"] },
        { name: "Visitor", tag: "Court séjour", icon: Plane, eligibility: ["Visite, tourisme ou activité autorisée sans étudier sur un cursus diplômant", "Démontrer le motif et l’intention de quitter le Royaume-Uni", "Disposer de moyens suffisants pour le séjour"], documents: ["Passeport et formulaire", "Itinéraire, hébergement et fonds", "Lettre d’invitation ou preuve d’activité si applicable"], process: ["Vérifier le visa selon la nationalité", "Préparer les preuves", "Déposer et voyager selon les conditions"] },
        { name: "Admissions", tag: "Universités & colleges", icon: BookOpen, eligibility: ["Niveau académique et anglais conformes au programme", "Candidature via UCAS ou directement auprès de l’établissement", "Budget et calendrier d’admission anticipés"], documents: ["Diplômes, relevés, CV et personal statement", "Références et preuve d’anglais", "Passeport et portfolio si le cours le demande"], process: ["Choisir les formations", "Recevoir une offre conditionnelle ou ferme", "Confirmer, obtenir le CAS et préparer le départ"] },
      ],
      admissions: ["Recherche de programme et vérification du sponsor", "Candidature UCAS ou portail de l’établissement", "Offre, conditions à remplir et dépôt éventuel", "CAS, Student visa et inscription à l’arrivée"],
      official: "https://www.gov.uk/student-visa",
    },
    usa: {
      label: "États-Unis",
      kicker: "Admissions · F / M / J",
      intro: "De la sélection d’une école approuvée à l’entretien consulaire, nous vous aidons à garder votre projet académique cohérent.",
      categories: [
        { name: "Visiteur B-1/B-2", tag: "Tourisme / affaires", icon: Plane, eligibility: ["Motif temporaire autorisé : tourisme, visite ou affaires B-1", "Démontrer l’intention de quitter les États-Unis après le séjour", "Disposer de fonds, attaches et admissibilité; aucune activité d’emploi ou étude diplômante"], documents: ["Passeport et confirmation DS-160", "Preuve du motif, itinéraire et hébergement", "Relevés, emploi, attaches et invitation si applicable"], process: ["Vérifier la nécessité du visa selon la nationalité", "Remplir DS-160 et payer 185 USD non remboursables", "Prendre rendez-vous, entretien consulaire et attendre la décision"] },
        { name: "F visa", tag: "Academic", icon: GraduationCap, eligibility: ["Admission dans une école approuvée par le SEVP", "Inscription dans SEVIS et réception du Form I-20", "Démontrer la préparation académique, les fonds et l’intention de départ"], documents: ["Passeport et confirmation DS-160", "Reçu de frais, photo et Form I-20 signé", "Diplômes, relevés, scores et preuves financières"], process: ["Postuler à une école SEVP", "Payer SEVIS et obtenir le I-20", "DS-160, rendez-vous, entretien et décision"] },
        { name: "M visa", tag: "Vocational", icon: BriefcaseBusiness, eligibility: ["Programme professionnel ou non académique reconnu", "Admission et Form I-20 M-1", "Fonds et projet d’études clairement documentés"], documents: ["I-20 M-1, DS-160 et passeport", "Preuve du paiement SEVIS", "Parcours académique et preuve de prise en charge"], process: ["Choisir l’institution", "Recevoir le I-20", "Préparer l’entretien et déposer la demande"] },
        { name: "J visa", tag: "Exchange", icon: UsersRound, eligibility: ["Programme d’échange avec sponsor désigné", "Form DS-2019 et inscription SEVIS", "Respect des règles du programme et de la catégorie"], documents: ["DS-2019, DS-160 et passeport", "Preuves financières et invitation", "Documents académiques et assurance si exigée"], process: ["Être sélectionné par le sponsor", "Payer les frais applicables", "Entretien consulaire et arrivée selon les conditions"] },
      ],
      admissions: ["Identifier une école et un programme adaptés", "Vérifier les deadlines, tests, bourses et exigences", "Obtenir l’admission puis le I-20 ou DS-2019", "Organiser SEVIS, DS-160, entretien et arrivée"],
      official: "https://travel.state.gov/content/travel/en/us-visas/study/student-visa.html",
    },
  },
  en: {
    canada: {
      label: "Canada", kicker: "Temporary & permanent residence", intro: "Prepare a visit, studies, employment or a skilled-worker profile with the right forms and evidence.",
      categories: [
        { name: "Visit", tag: "Visitor / eTA", icon: Plane, eligibility: ["Valid passport and entry document appropriate to your nationality", "Credible travel purpose, sufficient funds and intention to leave Canada", "General admissibility: security, health and background"], documents: ["Passport, form and photo", "Bank statements, employment and leave proof", "Itinerary, accommodation and invitation letter where applicable"], process: ["Determine visitor visa or eTA", "Prepare ties and funds evidence", "Apply online and provide biometrics if requested"] },
        { name: "Study", tag: "Study permit", icon: GraduationCap, eligibility: ["Letter of acceptance from a designated learning institution (DLI)", "PAL/TAL when required, unless an applicable exception applies", "Show funds, study purpose and ability to comply with conditions"], documents: ["Letter of acceptance and PAL/TAL", "Passport, forms, photo and biometrics", "Financial proof, letter of explanation and academic documents"], process: ["Choose a programme and secure admission", "Gather PAL/TAL and financial proof", "Apply online before travel and track the decision"] },
        { name: "Work", tag: "Open / employer-specific", icon: BriefcaseBusiness, eligibility: ["Offer, employer or situation granting access to the chosen category", "Meet conditions for an open or employer-specific permit", "General admissibility and, where applicable, medical or biometrics"], documents: ["Passport and forms", "Job offer, contract, LMIA or exemption proof where applicable", "CV, diplomas, experience and funds proof"], process: ["Identify the permit category", "Validate employer and requirements", "Submit the application and follow instructions"] },
        { name: "Express Entry", tag: "PR · skilled workers", icon: Route, eligibility: ["Three programmes: CEC, Federal Skilled Worker and Federal Skilled Trades", "Profile, experience, education and language assessed under programme rules", "Enter the pool, then receive an invitation based on score and draw type"], documents: ["Language test and credential assessment", "Employment letters, passports and experience evidence", "Settlement funds, police certificates and exams if required"], process: ["Create a profile and enter the pool", "Monitor score and rounds", "After invitation: complete forms, upload documents and pay fees"] },
      ], admissions: ["Choose an institution and programme", "Check entry conditions and deadlines", "Apply, receive the letter and complete enrolment", "Prepare study permit and arrival"], official: "https://www.canada.ca/en/immigration-refugees-citizenship.html",
    },
    schengen: {
      label: "Schengen", kicker: "Short stays · up to 90 days / 180", intro: "A common framework for short stays in the Schengen area: the responsible consulate depends, among other factors, on the main destination.",
      categories: [
        { name: "Tourism", tag: "Type C", icon: Plane, eligibility: ["Stay of no more than 90 days in any 180-day period", "Consistent main destination and travel purpose", "Proof of funds, accommodation and return"], documents: ["Passport, form, photo and travel insurance", "Reservations or itinerary and accommodation", "Bank statements, employment and ties"], process: ["Identify the main-destination consulate", "Book and prepare the file", "Biometrics, decision and travel within validity"] },
        { name: "Business", tag: "Type C", icon: BriefcaseBusiness, eligibility: ["Verifiable professional purpose or invitation", "Stay consistent with the temporary nature of the visa", "Documented resources and itinerary"], documents: ["Business invitation letter", "Employment letter and sponsorship", "Reservations, insurance and financial proof"], process: ["Clarify purpose and main country", "Prepare both parties’ letters", "Apply with the responsible provider"] },
        { name: "Family visit", tag: "Type C", icon: UsersRound, eligibility: ["Family relationship and purpose documented", "Accommodation or sponsorship justified", "Intention to return and sufficient funds"], documents: ["Invitation, proof of relationship and host ID", "Employment, funds and residence proof", "Travel medical insurance and reservations"], process: ["Build relationship evidence", "Check the consulate checklist", "Appointment, biometrics and tracking"] },
        { name: "Transit / medical", tag: "Specific cases", icon: Stethoscope, eligibility: ["Category matching the route or treatment", "Transit or medical-care proof", "Compliance with additional national rules"], documents: ["Full itinerary and final-destination visas", "Hospital letter or appointment proof", "Insurance and financial evidence"], process: ["Check if an airport transit visa is needed", "Obtain institution documents", "Submit to the competent post"] },
      ], admissions: ["For stays over 90 days, national procedures apply", "For study, distinguish short stay and national long-stay visa", "Check the competent representation before final bookings"], official: "https://home-affairs.ec.europa.eu/policies/schengen-borders-and-visa/visa-policy_en",
    },
    france: {
      label: "France", kicker: "Study, short stay & mobility", intro: "A pathway combining admission, Études en France where required and the visa application matching the duration and purpose.",
      categories: [
        { name: "Long-stay student", tag: "VLS-TS", icon: GraduationCap, eligibility: ["Choose a course and be accepted by a higher-education institution", "Follow Études en France if your country is covered", "For courses over three months: long-stay visa with arrival formalities"], documents: ["Enrolment or admission certificate", "Passport, form and documents requested by the visa wizard", "Funds, accommodation and academic background"], process: ["Apply to the institution / Campus France", "Secure admission and prepare the consular file", "Apply, then validate the visa after arrival if needed"] },
        { name: "Student examination", tag: "Short stay · max 90 days", icon: ClipboardList, eligibility: ["Be invited to an entrance exam or selection in France", "Show a serious and coherent study plan", "If admitted, regularisation may be possible subject to conditions"], documents: ["Exam invitation or summons", "Academic record and evidence of study seriousness", "Personal and financial documents from the visa wizard"], process: ["Obtain the summons", "Request the appropriate short-stay visa", "Leave Schengen if admission does not open a residence right"] },
        { name: "Visitor", tag: "Short / long stay", icon: MapPin, eligibility: ["Stay without professional activity in France", "Show resources and accommodation", "Respect the duration authorised by the visa"], documents: ["Passport, insurance and form", "Accommodation, funds and purpose", "Return evidence and ties in country of residence"], process: ["Use the visa wizard", "Book with the competent centre", "Track decision and arrival formalities"] },
      ], admissions: ["Identify degree and institution", "Check Parcoursup, Études en France or the institution’s own process", "Apply and respect calendars", "After admission: visa and administrative enrolment"], official: "https://france-visas.gouv.fr/en/etudiant",
    },
    belgique: {
      label: "Belgium", kicker: "Study & Schengen visas", intro: "Guidance to connect admission to a Belgian institution, proof of means and the appropriate visa application.",
      categories: [
        { name: "Student", tag: "Visa D", icon: GraduationCap, eligibility: ["Admission or enrolment in a recognised institution", "Study plan coherent with prior education", "Means of subsistence, insurance and administrative conditions met"], documents: ["Admission / enrolment letter", "Passport, form and photo", "Means, insurance, housing and academic documents"], process: ["Apply to the institution", "Secure enrolment and assemble evidence", "Apply for long stay then register after arrival"] },
        { name: "Schengen visit", tag: "Type C", icon: Plane, eligibility: ["Short stay within 90/180", "Belgium as main destination or coherent main destination", "Accommodation, funds and intention to return"], documents: ["Passport, form, photo and insurance", "Invitation or accommodation booking", "Bank statements, employment and itinerary"], process: ["Check competent consulate", "Book appointment and provide biometrics", "Travel according to decision and duration"] },
        { name: "Admissions", tag: "Bachelor · Master · PhD", icon: BookOpen, eligibility: ["Prior diploma compatible and required language level", "Meet deadlines and institution criteria", "Realistic study budget and academic plan"], documents: ["Certified diplomas and transcripts", "CV, motivation letter and language proof", "Passport and institution-specific documents"], process: ["Compare programmes", "Submit the application", "Confirm enrolment and prepare visa"] },
      ], admissions: ["Select institutions and check diploma recognition", "Prepare translations and legalisation if requested", "Apply on the university or college calendar", "After admission: Visa D, housing, insurance and enrolment"], official: "https://dofi.ibz.be/en/themes/third-country-nationals/study",
    },
    uk: {
      label: "England / UK", kicker: "Student visa & admissions", intro: "A pathway built around admission, the CAS and the evidence required by UKVI to study in the United Kingdom.",
      categories: [
        { name: "Student visa", tag: "16+ · UKVI", icon: GraduationCap, eligibility: ["Place on a course with a licensed student sponsor", "Required funds and proof of English", "Parental consent required for some 16–17-year-old applicants"], documents: ["CAS, passport and identity evidence", "Financial and English evidence", "ATAS, TB test or academic documents if required"], process: ["Apply and receive an offer", "Accept offer and obtain CAS", "Apply online and follow eVisa access"] },
        { name: "Visitor", tag: "Short stay", icon: Plane, eligibility: ["Visit, tourism or permitted activity without degree-level study", "Show purpose and intention to leave the UK", "Have enough money for the stay"], documents: ["Passport and form", "Itinerary, accommodation and funds", "Invitation or activity proof where applicable"], process: ["Check visa need for nationality", "Prepare evidence", "Apply and travel within conditions"] },
        { name: "Admissions", tag: "Universities & colleges", icon: BookOpen, eligibility: ["Academic level and English match the programme", "Apply through UCAS or directly to the institution", "Plan budget and admissions calendar early"], documents: ["Diplomas, transcripts, CV and personal statement", "References and English proof", "Passport and portfolio if required"], process: ["Choose courses", "Receive conditional or firm offer", "Confirm, get CAS and prepare departure"] },
      ], admissions: ["Research programmes and verify the sponsor", "Apply through UCAS or the institution portal", "Meet offer conditions and pay any deposit", "CAS, Student visa and arrival enrolment"], official: "https://www.gov.uk/student-visa",
    },
    usa: {
      label: "United States", kicker: "Admissions · F / M / J", intro: "From selecting an approved school to the consular interview, keep the academic project coherent from start to finish.",
      categories: [
        { name: "B-1/B-2 visitor", tag: "Tourism / business", icon: Plane, eligibility: ["Permitted temporary purpose: tourism, visit or B-1 business", "Show intent to leave the United States after the stay", "Have funds, ties and admissibility; no employment or degree study"], documents: ["Passport and DS-160 confirmation", "Purpose, itinerary and accommodation evidence", "Bank, employment, ties and invitation evidence where applicable"], process: ["Check visa need by nationality", "Complete DS-160 and pay the non-refundable USD 185 fee", "Book appointment, attend interview and await the decision"] },
        { name: "F visa", tag: "Academic", icon: GraduationCap, eligibility: ["Admission to a SEVP-approved school", "SEVIS registration and Form I-20", "Show academic preparation, funds and intent to depart"], documents: ["Passport and DS-160 confirmation", "Fee receipt, photo and signed Form I-20", "Diplomas, transcripts, scores and financial evidence"], process: ["Apply to a SEVP school", "Pay SEVIS and obtain I-20", "DS-160, appointment, interview and decision"] },
        { name: "M visa", tag: "Vocational", icon: BriefcaseBusiness, eligibility: ["Recognised vocational or non-academic programme", "Admission and M-1 Form I-20", "Clearly documented funds and study purpose"], documents: ["M-1 I-20, DS-160 and passport", "SEVIS payment proof", "Academic record and sponsorship evidence"], process: ["Choose the institution", "Receive I-20", "Prepare interview and apply"] },
        { name: "J visa", tag: "Exchange", icon: UsersRound, eligibility: ["Exchange programme with a designated sponsor", "DS-2019 and SEVIS registration", "Comply with programme and category rules"], documents: ["DS-2019, DS-160 and passport", "Funds and invitation proof", "Academic documents and insurance if required"], process: ["Be selected by the sponsor", "Pay applicable fees", "Consular interview and arrival under conditions"] },
      ], admissions: ["Identify an appropriate school and programme", "Check deadlines, tests, scholarships and requirements", "Secure admission then I-20 or DS-2019", "Organise SEVIS, DS-160, interview and arrival"], official: "https://travel.state.gov/content/travel/en/us-visas/study/student-visa.html",
    },
  },
};

const countryOrder: CountryKey[] = ["canada", "schengen", "france", "belgique", "uk", "usa"];

function Logo() {
  return (
    <a href="#top" className="flex items-center gap-3" aria-label="NZO Travel Agency - accueil">
      <span className="logo-mark"><Globe2 size={21} strokeWidth={1.8} /></span>
      <span className="font-display text-[1.06rem] tracking-[-0.02em] text-white">NZO <span className="font-sans text-[0.62rem] font-semibold uppercase tracking-[0.22em] text-sky-200">Travel Agency</span></span>
    </a>
  );
}

export default function Home() {
  const [lang, setLang] = useState<Lang>("fr");
  const [activeCountry, setActiveCountry] = useState<CountryKey>("canada");
  const [activeCategory, setActiveCategory] = useState(0);
  const [activeResearchTab, setActiveResearchTab] = useState<ResearchTab>("calendar");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [heroSlide, setHeroSlide] = useState(0);
  const t = copy[lang];
  const guide = guides[lang][activeCountry];
  const category = guide.categories[activeCategory] ?? guide.categories[0];
  const research = researchProfiles[activeCountry];
  const researchField = research[activeResearchTab];
  const categoryFee = categoryFeeDetails[activeCountry][activeCategory] ?? categoryFeeDetails[activeCountry][0];
  const processingTime = categoryProcessingTimes[activeCountry][activeCategory] ?? categoryProcessingTimes[activeCountry][0];
  const financialEvidence = financialEvidenceByCountry[activeCountry];
  const researchTabs: { key: ResearchTab; fr: string; en: string; icon: typeof CalendarDays }[] = [
    { key: "calendar", fr: "Calendrier & deadlines", en: "Calendar & deadlines", icon: CalendarDays },
    { key: "admissions", fr: "Admission Bachelor / Master", en: "Bachelor / Master admission", icon: GraduationCap },
    { key: "costs", fr: "Frais & coût de vie", en: "Fees & living costs", icon: Banknote },
    { key: "language", fr: "Tests linguistiques", en: "Language tests", icon: Languages },
    { key: "visa", fr: "Frais de visa", en: "Visa fees", icon: FileCheck2 },
    { key: "schools", fr: "Universités & collèges", en: "Universities & colleges", icon: Landmark },
  ];

  useEffect(() => {
    const timer = window.setInterval(() => setHeroSlide((current) => (current + 1) % heroSlides.length), 5200);
    return () => window.clearInterval(timer);
  }, []);

  const navItems = useMemo(() => [
    { href: "#services", label: t.nav[0] },
    { href: "#parcours", label: t.nav[1] },
    { href: "#guides", label: t.nav[2] },
    { href: "#accompagnement", label: t.nav[3] },
    { href: "#a-propos", label: t.nav[4] },
  ], [t]);

  const changeCountry = (country: CountryKey) => {
    setActiveCountry(country);
    setActiveCategory(0);
  };

  return (
    <div id="top" className="min-h-screen overflow-x-hidden bg-[#f7f9fc] text-[#0d1b34]">
      <header className="site-header">
        <div className="container flex h-[76px] items-center justify-between gap-6">
          <Logo />
          <nav className="hidden items-center gap-7 lg:flex" aria-label="Navigation principale">
            {navItems.map((item) => <a key={item.href} href={item.href} className="nav-link">{item.label}</a>)}
          </nav>
          <div className="flex items-center gap-3">
            <div className="language-switch" aria-label={t.language}>
              <button className={lang === "fr" ? "active" : ""} onClick={() => setLang("fr")} type="button">FR</button>
              <span>/</span>
              <button className={lang === "en" ? "active" : ""} onClick={() => setLang("en")} type="button">EN</button>
            </div>
            <a href="https://wa.me/25768457000?text=Bonjour%20NZO%20Travel%20Agency%2C%20je%20souhaite%20parler%20de%20mon%20projet." target="_blank" rel="noreferrer" className="hidden rounded-full bg-[#2f8f62] px-5 py-2.5 text-[0.7rem] font-bold uppercase tracking-[0.11em] text-[#0b2546] transition hover:-translate-y-0.5 hover:bg-[#46aa78] sm:inline-flex">{t.primary}</a>
            <button className="mobile-menu-button lg:hidden" onClick={() => setMobileOpen(!mobileOpen)} aria-label="Menu" type="button">{mobileOpen ? <X size={20} /> : <Menu size={20} />}</button>
          </div>
        </div>
        {mobileOpen && <div className="mobile-nav lg:hidden">{navItems.map((item) => <a key={item.href} href={item.href} onClick={() => setMobileOpen(false)}>{item.label}<ArrowUpRight size={14} /></a>)}</div>}
      </header>

      <main>
        <section className="hero-section">
          <div className="hero-image" aria-label={heroSlides[heroSlide].alt}><div key={heroSlides[heroSlide].image} className={`hero-photo hero-photo-active hero-photo-${heroSlide}`} style={{ backgroundImage: `url('${heroSlides[heroSlide].image}')` }} /><div className="hero-photo-overlay" /></div>
          <div className="hero-grid" aria-hidden="true" />
          <div className="container relative z-10 grid min-h-[690px] items-end pb-16 pt-28 lg:min-h-[730px] lg:grid-cols-[1fr_0.72fr] lg:pb-24">
            <div className="max-w-[680px]">
              <div className="eyebrow text-[#d6f5e2]"><span className="eyebrow-dot" />{t.heroEyebrow}</div>
              <h1 className="hero-title mt-7 max-w-[680px]">{t.heroTitle}</h1>
              <p className="hero-body mt-7 max-w-[560px]">{t.heroBody}</p>
              <div className="mt-9 flex flex-col items-start gap-3 sm:flex-row sm:items-center">
                <a href="#contact" className="primary-button">{t.primary}<ArrowRight size={16} /></a>
                <a href="#guides" className="secondary-button">{t.secondary}<ArrowUpRight size={16} /></a>
              </div>
              <div className="mt-9 flex items-center gap-3 text-[0.66rem] font-semibold uppercase tracking-[0.13em] text-slate-300"><ShieldCheck size={15} className="text-[#d6f5e2]" />{t.trust}</div>
            </div>
            <div className="hidden justify-self-end lg:block">
              <div className="hero-note">
                <span className="hero-note-index">0{heroSlide + 1} / 03</span>
                <p className="font-display text-[1.6rem] leading-[1.08] text-white">{lang === "fr" ? heroSlides[heroSlide].fr : heroSlides[heroSlide].en}</p>
                <div className="mt-6 h-px w-full bg-white/15" />
                <div className="mt-4 flex items-center justify-between text-[0.66rem] uppercase tracking-[0.16em] text-slate-300"><span>BUJUMBURA</span><span>WORLDWIDE</span></div>
                <div className="hero-slide-dots" role="tablist" aria-label={lang === "fr" ? "Destinations du carrousel" : "Carousel destinations"}>{heroSlides.map((slide, index) => <button key={slide.image} type="button" role="tab" aria-label={lang === "fr" ? `Afficher ${slide.fr}` : `Show ${slide.en}`} aria-selected={heroSlide === index} className={heroSlide === index ? "active" : ""} onClick={() => setHeroSlide(index)} />)}</div>
              </div>
            </div>
          </div>
          <div className="hero-bottom-line"><span /> <span>{lang === "fr" ? "Démarrer une conversation" : "Start a conversation"}</span> <ArrowDownGlyph /></div>
        </section>

        <section className="intro-section" id="services">
          <div className="container grid gap-12 py-24 lg:grid-cols-[0.48fr_1fr] lg:gap-24 lg:py-32">
            <div><div className="eyebrow dark"><span className="eyebrow-dot blue" />{t.welcome}</div><div className="section-rule mt-5" /></div>
            <div className="max-w-[820px]"><h2 className="display-heading">{t.introTitle}</h2><p className="large-body mt-7 max-w-[730px]">{t.introBody}</p></div>
          </div>
        </section>

        <section className="services-section">
          <div className="container py-20 lg:py-28">
            <div className="flex flex-col justify-between gap-8 md:flex-row md:items-end"><div><div className="eyebrow dark"><span className="eyebrow-dot blue" />{t.servicesTitle}</div><h2 className="display-heading mt-5 max-w-[650px]">{t.servicesBody}</h2></div><span className="section-number">01—03</span></div>
            <div className="service-grid mt-16">
              {t.services.map((service, index) => { const Icon = service.icon; return <div className="service-card" key={service.title}><div className="service-card-top"><span className="service-index">0{index + 1}</span><Icon size={26} strokeWidth={1.6} /></div><h3>{service.title}</h3><p>{service.body}</p><a href="#guides" className="service-link">{lang === "fr" ? "Voir les voies" : "See pathways"}<ArrowUpRight size={14} /></a></div>; })}
            </div>
          </div>
        </section>

        <section className="path-section" id="parcours">
          <div className="container grid gap-12 py-24 lg:grid-cols-[0.75fr_1fr] lg:gap-24 lg:py-32">
            <div className="path-intro"><div className="eyebrow text-[#d6f5e2]"><span className="eyebrow-dot" />{t.pathTitle}</div><h2 className="display-heading light mt-5">{t.pathBody}</h2></div>
            <div className="steps-list">{t.steps.map((step, index) => <div className="step-row" key={step}><span className="step-count">0{index + 1}</span><span className="step-label">{step}</span><ArrowRight size={17} /></div>)}</div>
          </div>
        </section>

        <section id="guides" className="guides-section">
          <div className="container py-24 lg:py-32">
            <div className="max-w-[780px]"><div className="eyebrow dark"><span className="eyebrow-dot blue" />{t.guideEyebrow}</div><h2 className="display-heading mt-5">{t.guideTitle}</h2><p className="large-body mt-6 max-w-[680px]">{t.guideBody}</p></div>
            <div className="country-tabs mt-12" role="tablist" aria-label={t.guideEyebrow}>{countryOrder.map((country) => <button key={country} role="tab" aria-selected={activeCountry === country} className={activeCountry === country ? "active" : ""} onClick={() => changeCountry(country)} type="button"><span className="country-code">{country === "uk" ? "GB" : country === "usa" ? "US" : country === "schengen" ? "EU" : country === "belgique" ? "BE" : country === "france" ? "FR" : "CA"}</span>{guides[lang][country].label}</button>)}</div>
            <div className="guide-panel mt-4">
              <div className="guide-panel-heading"><div><span className="guide-kicker">{guide.kicker}</span><h3>{guide.label}</h3><p>{guide.intro}</p></div><a href={guide.official} target="_blank" rel="noreferrer" className="official-link">{t.official}<ArrowUpRight size={15} /></a></div>
              <div className="category-tabs" role="tablist" aria-label={`${guide.label} categories`}>{guide.categories.map((item, index) => { const Icon = item.icon; return <button key={item.name} className={activeCategory === index ? "active" : ""} onClick={() => setActiveCategory(index)} type="button"><Icon size={16} />{item.name}<span className="category-tag">{item.tag}</span></button>; })}</div>
              <div className="guide-content">
                <div className="guide-main"><div className="category-title-row"><div className="category-icon"><category.icon size={24} /></div><div><span className="guide-kicker">{category.tag}</span><h4>{category.name}</h4></div></div><div className="detail-columns mt-8"><DetailList title={t.eligibility} items={category.eligibility} icon={<ShieldCheck size={16} />} /><DetailList title={t.documents} items={category.documents} icon={<FileText size={16} />} /></div></div>
                <div className="process-card"><div className="process-card-title"><span>{t.process}</span><ScanLine size={17} /></div>{category.process.map((item, index) => <div className="mini-step" key={item}><span>{index + 1}</span><p>{item}</p></div>)}</div>
              </div>
              <div className="admissions-strip"><div className="admissions-label"><BookOpen size={16} />{t.admissions}</div><div className="admissions-items">{guide.admissions.map((item) => <span key={item}><Check size={13} />{item}</span>)}</div></div>
            </div>
            <div className="category-fee-card mt-5"><div className="category-fee-heading"><div><span className="guide-kicker">{lang === "fr" ? "FRAIS & DÉMARCHES DE CETTE CATÉGORIE" : "FEES & PROCESS FOR THIS CATEGORY"}</span><h3>{category.name}</h3></div><Banknote size={19} /></div><div className="category-fee-list">{categoryFee[lang].map((item) => <div className="category-fee-item" key={item}><Check size={15} /><p>{item}</p></div>)}<div className="category-fee-item processing-time"><Clock3 size={15} /><p><strong>{lang === "fr" ? "Délai indicatif :" : "Indicative processing time:"}</strong> {processingTime}</p></div></div></div>
            <div className="research-panel mt-8">
              <div className="research-panel-heading"><div><span className="guide-kicker">{lang === "fr" ? "REPÈRES OFFICIELS · 2026" : "OFFICIAL REFERENCE · 2026"}</span><h3>{lang === "fr" ? "Préparer son budget et son calendrier" : "Plan your budget and timeline"}</h3><p>{lang === "fr" ? "Une synthèse de repères universitaires et administratifs pour comparer les destinations. Les établissements, programmes et autorités restent seuls compétents pour confirmer les conditions." : "A summary of university and administrative reference points for comparing destinations. Institutions, programmes and authorities remain solely responsible for confirming requirements."}</p></div><CircleHelp size={20} /></div>
              <div className="research-tabs" role="tablist" aria-label={lang === "fr" ? "Repères par pays" : "Country reference tabs"}>{researchTabs.map((tab) => { const Icon = tab.icon; return <button key={tab.key} className={activeResearchTab === tab.key ? "active" : ""} role="tab" aria-selected={activeResearchTab === tab.key} onClick={() => setActiveResearchTab(tab.key)} type="button"><Icon size={15} />{lang === "fr" ? tab.fr : tab.en}</button>; })}</div>
              <div className="research-content"><div className="research-country-mark"><span>{guide.label}</span><small>{lang === "fr" ? "Source officielle à vérifier avant dépôt" : "Official source to recheck before filing"}</small></div><div className="research-list">{researchField[lang].map((item) => <div className="research-item" key={item}><Check size={15} /><p>{item}</p></div>)}</div></div>
            </div>
            <section className="financial-section mt-8" aria-labelledby="financial-title"><div className="financial-heading"><div><span className="guide-kicker">{lang === "fr" ? "PREUVES FINANCIÈRES" : "FINANCIAL EVIDENCE"}</span><h3 id="financial-title">{lang === "fr" ? `Documents financiers — ${guide.label}` : `Financial documents — ${guide.label}`}</h3><p>{lang === "fr" ? "Exemples à adapter à la catégorie et à la liste officielle du pays." : "Examples to adapt to the route and the country’s official checklist."}</p></div><Banknote size={19} /></div><div className="financial-list">{financialEvidence[lang].map((item) => <div className="financial-item" key={item}><Check size={15} /><p>{item}</p></div>)}</div></section>
            <section className="faq-section mt-8" aria-labelledby="faq-title"><div className="faq-heading"><div><span className="guide-kicker">FAQ · {guide.label}</span><h3 id="faq-title">{lang === "fr" ? `Questions fréquentes — ${category.name}` : `Frequently asked — ${category.name}`}</h3></div><CircleHelp size={19} /></div><div className="faq-list"><details open><summary>{lang === "fr" ? "Quels frais dois-je prévoir ?" : "Which fees should I plan for?"}</summary><p>{categoryFee[lang][0]}</p></details><details><summary>{lang === "fr" ? "Quelles pièces préparer ?" : "Which documents should I prepare?"}</summary><p>{category.documents.join(" · ")}</p></details><details><summary>{lang === "fr" ? "Quelles sont les étapes ?" : "What are the steps?"}</summary><p>{category.process.join(" · ")}</p></details><details><summary>{lang === "fr" ? "Que faire en cas de refus ?" : "What should I do after a refusal?"}</summary><p>{lang === "fr" ? `Pour la catégorie ${category.name}, lire la lettre de refus et ses motifs, vérifier s’il existe un recours ou une demande de réexamen, puis corriger les causes documentées avant toute nouvelle demande. Une nouvelle soumission identique ne garantit pas un résultat différent.` : `For ${category.name}, read the refusal letter and reasons, check whether an appeal or review is available, then correct the documented weaknesses before reapplying. An identical resubmission does not guarantee a different outcome.`}</p></details></div></section>
            <p className="source-note mt-5"><CircleHelp size={15} />{t.sourceNote}</p>
          </div>
        </section>

        <section className="checklist-section">
          <div className="container grid gap-12 py-24 lg:grid-cols-[0.55fr_1fr] lg:gap-24 lg:py-28"><div><div className="eyebrow dark"><span className="eyebrow-dot blue" />{t.checklistTitle}</div><h2 className="display-heading mt-5">{t.checklistBody}</h2></div><div className="checklist-grid">{t.checklist.map((item, index) => <div className="checklist-item" key={item}><span>0{index + 1}</span><Check size={15} /><p>{item}</p></div>)}</div></div>
        </section>

        <section id="accompagnement" className="support-section">
          <div className="container py-24 lg:py-32">
            <div className="max-w-[760px]"><div className="eyebrow dark"><span className="eyebrow-dot blue" />{t.supportEyebrow}</div><h2 className="display-heading mt-5">{t.supportTitle}</h2><p className="large-body mt-6">{t.supportBody}</p></div>
            <div className="support-grid mt-12"><div className="support-card featured"><div className="support-card-top"><span>{t.initialLabel}</span><span className="support-price">{t.initialPrice}</span></div><p>{t.initialBody}</p><div className="support-note"><ShieldCheck size={15} />{t.initialNote}</div></div><div className="support-card"><div className="support-card-top"><span>{t.tailoredLabel}</span><span className="support-price">{t.tailoredPrice}</span></div><p>{t.tailoredBody}</p><div className="support-note"><Route size={15} />{t.tailoredNote}</div></div></div>
            <div className="support-disclaimer"><Landmark size={17} />{t.supportDisclaimer}</div>
          </div>
        </section>

        <section id="a-propos" className="expert-section">
          <div className="container grid gap-12 py-24 lg:grid-cols-[0.7fr_1fr] lg:gap-24 lg:py-32"><div className="expert-card"><div className="expert-avatar">AI</div><div className="mt-7 flex items-center gap-2 text-[0.67rem] font-semibold uppercase tracking-[0.16em] text-sky-200"><MapPin size={14} />Bujumbura, Burundi</div><a href="https://www.linkedin.com/in/alex-entrepreneur" target="_blank" rel="noreferrer" className="linkedin-button mt-6"><Linkedin size={15} />LinkedIn <ArrowUpRight size={14} /></a></div><div className="expert-copy"><div className="eyebrow text-[#d6f5e2]"><span className="eyebrow-dot" />{t.expertEyebrow}</div><h2 className="display-heading light mt-5">{t.expertTitle}</h2><p className="large-body light mt-7">{t.expertBody}</p><a href="https://www.linkedin.com/in/alex-entrepreneur" target="_blank" rel="noreferrer" className="text-link mt-8">{t.viewLinkedin}<ArrowRight size={16} /></a></div></div>
        </section>

        <section id="contact" className="contact-section">
          <div className="container grid gap-12 py-24 lg:grid-cols-[0.85fr_1fr] lg:gap-24 lg:py-32"><div><div className="eyebrow dark"><span className="eyebrow-dot blue" />{lang === "fr" ? "PREMIÈRE ÉTAPE" : "FIRST STEP"}</div><h2 className="display-heading mt-5">{t.contactTitle}</h2><p className="large-body mt-6">{t.contactBody}</p><div className="contact-quick mt-9"><a href="https://wa.me/25768457000?text=Bonjour%20NZO%20Travel%20Agency%2C%20je%20souhaite%20parler%20de%20mon%20projet." target="_blank" rel="noreferrer"><MessageCircle size={17} />+257 68 45 70 00</a><a href="mailto:irakozestartup@gmail.com?subject=Projet%20international%20-%20NZO%20Travel%20Agency"><Mail size={17} />irakozestartup@gmail.com</a></div></div><ContactForm lang={lang} /></div>
        </section>

        <section className="disclaimer-section"><div className="container py-12 lg:py-16"><div className="disclaimer-box"><div className="disclaimer-icon"><Landmark size={20} /></div><div><h2>{t.disclaimerTitle}</h2><p>{t.disclaimer}</p></div></div></div></section>
      </main>

      <footer className="footer-section"><div className="container py-10"><div className="flex flex-col justify-between gap-8 border-b border-white/10 pb-10 md:flex-row md:items-start"><div><Logo /><p className="mt-5 max-w-[320px] text-sm leading-6 text-slate-400">{t.footer}</p></div><div className="footer-links"><span>{t.officialSources}</span><a href="https://www.canada.ca/en/immigration-refugees-citizenship.html" target="_blank" rel="noreferrer">Canada.ca</a><a href="https://france-visas.gouv.fr/en/etudiant" target="_blank" rel="noreferrer">France-Visas</a><a href="https://www.gov.uk/student-visa" target="_blank" rel="noreferrer">GOV.UK</a><a href="https://travel.state.gov/content/travel/en-us/visas/study/student-visa.html" target="_blank" rel="noreferrer">Travel.State.Gov</a><a href="/politique-de-confidentialite">{lang === "fr" ? "Politique de confidentialité" : "Privacy policy"}</a></div></div><div className="flex flex-col justify-between gap-3 pt-7 text-[0.68rem] uppercase tracking-[0.15em] text-slate-500 sm:flex-row"><span>© {new Date().getFullYear()} NZO Travel Agency</span><a href="#top" className="flex items-center gap-2 hover:text-white">{t.scrollTop}<ChevronDown size={13} className="rotate-180" /></a></div></div></footer>
    </div>
  );
}

function DetailList({ title, items, icon }: { title: string; items: string[]; icon: React.ReactNode }) {
  return <div className="detail-list"><div className="detail-list-heading">{icon}<span>{title}</span></div>{items.map((item) => <div className="detail-item" key={item}><Check size={14} /><p>{item}</p></div>)}</div>;
}

function ArrowDownGlyph() { return <span className="arrow-down-glyph"><span /></span>; }
