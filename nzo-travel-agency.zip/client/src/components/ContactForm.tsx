import { FormEvent, useState } from "react";
import { CheckCircle2, Loader2, Mail, Send } from "lucide-react";

const labels = {
  fr: { kicker: "FORMULAIRE DE CONTACT", title: "Décrivez votre projet", first: "Prénom", last: "Nom", whatsapp: "Numéro WhatsApp", whatsappHint: "Ajoutez les chiffres après l’indicatif", whatsappInvalid: "Saisissez un numéro international valide avec + et 8 à 15 chiffres.", visa: "Visa recherché", country: "Pays concerné", message: "Votre message", consent: "J’accepte le disclaimer : NZO Travel Agency accompagne et conseille, sans garantir l’obtention d’un visa ou d’une admission.", submit: "Ouvrir l’email", preparing: "Préparation de l’email…", confirmation: "Votre message est prêt. Votre logiciel de messagerie va s’ouvrir.", fallback: "Si aucun logiciel email ne s’ouvre, copiez l’adresse suivante ou cliquez ici pour réessayer :", note: "Votre logiciel de messagerie s’ouvrira avec les informations saisies.", chooseCountry: "Indicatif du pays" },
  en: { kicker: "CONTACT FORM", title: "Tell us about your project", first: "First name", last: "Last name", whatsapp: "WhatsApp number", whatsappHint: "Add the digits after the country code", whatsappInvalid: "Enter a valid international number with + and 8 to 15 digits.", visa: "Visa sought", country: "Country concerned", message: "Your message", consent: "I accept the disclaimer: NZO Travel Agency provides guidance and support without guaranteeing a visa or admission.", submit: "Open email", preparing: "Preparing email…", confirmation: "Your message is ready. Your email application will open.", fallback: "If no email application opens, copy the address below or click here to try again:", note: "Your email application will open with the information entered.", chooseCountry: "Country code" },
};

const countryDialCodes = [
  { country: "Burundi", iso: "BI", code: "+257" }, { country: "Rwanda", iso: "RW", code: "+250" }, { country: "RD Congo", iso: "CD", code: "+243" },
  { country: "Tanzanie", iso: "TZ", code: "+255" }, { country: "Kenya", iso: "KE", code: "+254" }, { country: "Ouganda", iso: "UG", code: "+256" },
  { country: "France", iso: "FR", code: "+33" }, { country: "Belgique", iso: "BE", code: "+32" }, { country: "Royaume-Uni", iso: "GB", code: "+44" },
  { country: "Canada", iso: "CA", code: "+1" }, { country: "États-Unis", iso: "US", code: "+1" }, { country: "Allemagne", iso: "DE", code: "+49" },
  { country: "Suisse", iso: "CH", code: "+41" },
];

export function getCountryCodeFromLocale(locale?: string) {
  const region = locale?.split("-")[1]?.toUpperCase();
  return countryDialCodes.find((item) => item.iso === region)?.code ?? "+257";
}

function detectDialCode() {
  if (typeof navigator === "undefined") return "+257";
  const localeCode = getCountryCodeFromLocale(navigator.language);
  if (localeCode !== "+257" || navigator.language.toLowerCase().startsWith("fr")) return localeCode;
  const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  if (timezone.includes("Kigali")) return "+250";
  if (timezone.includes("Paris")) return "+33";
  if (timezone.includes("Brussels")) return "+32";
  if (timezone.includes("London")) return "+44";
  return "+257";
}

export type ContactFormValues = { firstName: string; lastName: string; whatsapp: string; visa: string; country: string; message: string };
export function isValidWhatsAppNumber(value: string) { return /^\+[1-9]\d{7,14}$/.test(value); }
export function buildContactMailto(form: ContactFormValues, lang: "fr" | "en") {
  const t = labels[lang];
  const subject = `NZO Travel Agency — ${form.firstName} ${form.lastName} — WhatsApp ${form.whatsapp}`;
  const body = `${t.first}: ${form.firstName}\n${t.last}: ${form.lastName}\n${t.whatsapp}: ${form.whatsapp}\n${t.visa}: ${form.visa}\n${t.country}: ${form.country}\n\n${t.message}:\n${form.message}`;
  return `mailto:irakozestartup@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}

export default function ContactForm({ lang }: { lang: "fr" | "en" }) {
  const t = labels[lang];
  const [isPreparing, setIsPreparing] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [showFallback, setShowFallback] = useState(false);
  const [whatsappError, setWhatsappError] = useState(false);
  const [dialCode, setDialCode] = useState(detectDialCode);
  const [form, setForm] = useState(() => ({ firstName: "", lastName: "", whatsapp: detectDialCode(), visa: "", country: "", message: "" }));
  const update = (field: keyof typeof form, value: string) => setForm((current) => ({ ...current, [field]: value }));
  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (isPreparing) return;
    if (!isValidWhatsAppNumber(form.whatsapp)) {
      setWhatsappError(true);
      return;
    }
    setIsPreparing(true);
    setShowConfirmation(true);
    const mailto = buildContactMailto(form, lang);
    let emailAppOpened = false;
    const markEmailAppOpened = () => { emailAppOpened = true; };
    window.addEventListener("blur", markEmailAppOpened, { once: true });
    window.setTimeout(() => { window.location.href = mailto; }, 900);
    window.setTimeout(() => { window.removeEventListener("blur", markEmailAppOpened); if (!emailAppOpened) setShowFallback(true); }, 1700);
  };
  const inputClass = "w-full rounded-lg border border-[#d5e1ee] bg-white px-3 py-2.5 text-sm text-[#19365d] outline-none transition focus:border-[#1558c7] focus:ring-2 focus:ring-[#1558c7]/10";
  const labelClass = "grid gap-1.5 text-[0.62rem] font-extrabold uppercase tracking-[0.1em] text-[#60738d]";
  return (
    <form onSubmit={submit} className="contact-form-card">
      <div className="contact-form-head"><div><span className="guide-kicker">{t.kicker}</span><h3>{t.title}</h3></div><Mail size={19} /></div>
      <div className="grid gap-3 sm:grid-cols-2">
        <label className={labelClass}>{t.first}<input className={inputClass} required value={form.firstName} onChange={(event) => update("firstName", event.target.value)} /></label>
        <label className={labelClass}>{t.last}<input className={inputClass} required value={form.lastName} onChange={(event) => update("lastName", event.target.value)} /></label>
      </div>
      <div className="grid gap-3 sm:grid-cols-[.72fr_1.28fr]"><label className={labelClass}>{t.chooseCountry}<select className={inputClass} value={dialCode} onChange={(event) => { const next = event.target.value; setDialCode(next); update("whatsapp", next); setWhatsappError(false); }}>{countryDialCodes.map((item) => <option value={item.code} key={`${item.iso}-${item.code}`}>{item.country} ({item.code})</option>)}</select></label><label className={labelClass}>{t.whatsapp}<input className={inputClass} required type="tel" inputMode="tel" pattern="^\+[1-9][0-9]{7,14}$" minLength={9} maxLength={16} title={t.whatsappInvalid} placeholder={`${dialCode} …`} value={form.whatsapp} aria-invalid={whatsappError} onChange={(event) => { setWhatsappError(false); update("whatsapp", event.target.value); }} onBlur={() => setWhatsappError(Boolean(form.whatsapp) && !isValidWhatsAppNumber(form.whatsapp))} />{whatsappError && <span className="contact-field-error" role="alert">{t.whatsappInvalid}</span>}<small className="contact-field-hint">{t.whatsappHint}</small></label></div>
      <div className="grid gap-3 sm:grid-cols-2">
        <label className={labelClass}>{t.visa}<input className={inputClass} required placeholder={lang === "fr" ? "Ex. permis d’études" : "E.g. study permit"} value={form.visa} onChange={(event) => update("visa", event.target.value)} /></label>
        <label className={labelClass}>{t.country}<input className={inputClass} required placeholder={lang === "fr" ? "Ex. Canada" : "E.g. Canada"} value={form.country} onChange={(event) => update("country", event.target.value)} /></label>
      </div>
      <label className={labelClass}>{t.message}<textarea className={`${inputClass} min-h-24 resize-y`} required value={form.message} onChange={(event) => update("message", event.target.value)} /></label>
      <label className="flex items-start gap-2 text-[0.68rem] leading-[1.45] text-[#60738d]"><input className="mt-0.5 h-4 w-4 flex-none accent-[#1558c7]" type="checkbox" required /> <span>{t.consent}</span></label>
      {showConfirmation && <div className="contact-form-confirmation" role="status"><CheckCircle2 size={17} /><span>{t.confirmation}</span></div>}
      <button type="submit" disabled={isPreparing} className={`contact-form-submit ${isPreparing ? "is-preparing" : ""}`}><span className="contact-form-icon">{isPreparing ? <Loader2 size={15} /> : <Send size={15} />}</span>{isPreparing ? t.preparing : t.submit}</button>
      {showFallback && <div className="contact-form-fallback" role="alert"><span>{t.fallback}</span> <a href={buildContactMailto(form, lang)}>irakozestartup@gmail.com</a></div>}
      <p className="contact-form-note">{t.note}</p>
    </form>
  );
}
