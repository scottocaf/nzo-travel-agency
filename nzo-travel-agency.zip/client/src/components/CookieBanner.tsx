import { useEffect, useState } from "react";
import { Cookie, X } from "lucide-react";

export default function CookieBanner() {
  const [visible, setVisible] = useState(false);
  useEffect(() => { setVisible(window.localStorage.getItem("nzo-cookie-consent") === null); }, []);
  const decide = (value: "accepted" | "rejected") => { window.localStorage.setItem("nzo-cookie-consent", value); setVisible(false); };
  if (!visible) return null;
  return <aside className="cookie-banner" role="dialog" aria-label="Consentement aux cookies"><div className="cookie-banner-icon"><Cookie size={19} /></div><div className="cookie-banner-copy"><strong>Cookies &amp; confidentialité</strong><p>Nous utilisons des cookies et technologies similaires pour le fonctionnement du site. Vous pouvez accepter ou refuser.</p><a href="/politique-de-confidentialite">Lire la politique de confidentialité</a></div><div className="cookie-banner-actions"><button className="cookie-accept" onClick={() => decide("accepted")} type="button">Accepter</button><button className="cookie-reject" onClick={() => decide("rejected")} type="button">Refuser</button></div><button className="cookie-close" onClick={() => decide("rejected")} type="button" aria-label="Fermer"><X size={16} /></button></aside>;
}
