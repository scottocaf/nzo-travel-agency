import { MessageCircle } from "lucide-react";

export default function FloatingWhatsApp() {
  return <a className="floating-whatsapp" href="https://wa.me/25768457000?text=Bonjour%20NZO%20Travel%20Agency%2C%20je%20souhaite%20parler%20de%20mon%20projet." target="_blank" rel="noreferrer" aria-label="Contacter NZO Travel Agency sur WhatsApp"><MessageCircle size={24} /><span>WhatsApp</span></a>;
}
