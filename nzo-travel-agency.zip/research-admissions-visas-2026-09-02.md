# Notes de recherche — admissions, coûts et visas

Recherche effectuée le 2 septembre 2026 auprès de sources officielles gouvernementales et universitaires. Les dates et frais ci-dessous sont des repères documentés, non des garanties. Les montants varient selon établissement, programme, année, nationalité, ville et prestataire.

## Canada

Repères vérifiés : UBC Winter Session 2027-2028, candidature Bachelor au 15 janvier 2027; McGill Advanced Levels, candidature au 15 janvier et pièces au 1er mars. UBC publie des frais internationaux Bachelor 2026/27 d’environ 48 779,80 à 67 237,20 CAD selon programme. UBC publie IELTS 6,5 total avec aucune partie sous 6,0; TOEFL iBT 90 avec sous-scores; PTE 65; Cambridge 180; CAEL 70; DET 125. Permis d’études CAD 150, biométrie CAD 85, visa visiteur CAD 100, eTA CAD 7. PAL/TAL et CAQ Québec peuvent être requis.

Sources : https://you.ubc.ca/applying-ubc/dates-deadlines/ ; https://students.ubc.ca/enrolment/finances/tuition-fees/undergraduate-tuition-fees ; https://you.ubc.ca/applying-ubc/requirements/english-language-competency/ ; https://ircc.canada.ca/english/information/fees/fees.asp ; https://www.canada.ca/en/immigration-refugees-citizenship/services/study-canada/study-permit/get-documents.html ; https://www.mcgill.ca/undergraduate-admissions/apply/requirements/international/advanced-levels

## France

Repères vérifiés : Parcoursup 2026, vœux du 19 janvier au 12 mars, dossier jusqu’au 1er avril, admission principale du 2 juin au 11 juillet; DAP généralement d’octobre à mi-décembre; Mon Master 2027 à surveiller à partir de février 2027. Droits publics 2026/27 : 178 EUR Licence et 255 EUR Master pour UE/EEE/Suisse; 2 902 EUR Licence et 3 950 EUR Master pour hors UE, avec exemptions et tarifs spécifiques possibles. CVEC UGA 105 EUR. Ressources administratives étudiant : 877,50 EUR/mois. Visa étudiant EEF 50 EUR, autres pays 99 EUR; validation VLS-TS 100 EUR. Aucun seuil national unique pour Burundi/Rwanda, Cambridge, Edexcel ou SAT.

Sources : https://www.parcoursup.gouv.fr/calendrier ; https://www.monmaster.gouv.fr/calendrier ; https://www.campusfrance.org/en/tuition-fees-France ; https://france-visas.gouv.fr/frais-de-visa ; https://www.service-public.gouv.fr/particuliers/vosdroits/F2863 ; https://www.service-public.gouv.fr/particuliers/vosdroits/F2231 ; https://www.univ-grenoble-alpes.fr/les-frais-d-inscription/les-frais-d-inscription-600791.kjsp

## Belgique

Repères vérifiés : UGent recommande une candidature complète au 1er avril avec visa et au 1er juin sans visa; Study in Flanders 2026/27 donne des lignes directrices 1 181,40 EUR UE/EEE et 5 300–12 000 EUR hors UE/EEE pour 60 ECTS. KU Leuven candidature 90 EUR. Moyens de subsistance publiés pour 2026/27 : 1 062 EUR/mois, minimum administratif et non budget garanti. UAntwerpen : IELTS 6,5/6,0 par partie, PTE 59, Cambridge B2 First 176; VUB : IELTS 6,5/6,0 et Cambridge 170. Aucun seuil général Burundi/Rwanda, Edexcel ou SAT.

Sources : https://www.studyinflanders.be/practical-information/tuition-fees ; https://www.ugent.be/prospect/en/administration/application/application-degree/deadlines.htm ; https://www.kuleuven.be/english/apply/requested-documents/application-fee ; https://www.uantwerpen.be/en/study/admission-and-enrolment/admission/academic-bachelor/admission-requirements/ ; https://www.vub.be/en/studying-vub/apply-and-enrol-vub/admission-requirements-and-deadlines/academic-and-language-requirements ; https://republiquedecoree.diplomatie.belgium.be/en/travel-belgium/visa-belgium/visa-long-stays-over-90-days/student-visa

## Royaume-Uni

Repères vérifiés : UCAS 2026, 15 octobre pour Oxford/Cambridge et cursus médicaux, 14 janvier pour la plupart des cursus, 30 juin avant Clearing, 24 septembre date finale. Cambridge undergraduate international 2026 : 29 052 à 70 554 GBP/an selon cursus, College fee en plus. Student visa 558 GBP; IHS étudiant 776 GBP/an. Preuve de fonds : 1 529 GBP/mois Londres ou 1 171 GBP/mois hors Londres, jusqu’à neuf mois. Niveau UKVI B2 pour degree-level; Cambridge IELTS généralement 7,5 total, 7,0 par composante. Candidature postgraduate Cambridge : 20 GBP doctoral, 85 GBP autres cursus. Aucun seuil général pour le secondaire Burundi/Rwanda, Edexcel ou SAT.

Sources : https://www.ucas.com/undergraduate/applying-university/ucas-undergraduate-when-apply ; https://www.undergraduate.study.cam.ac.uk/international-students/international-fees-and-costs ; https://www.undergraduate.study.cam.ac.uk/applying/entrance-requirements/english-language-requirements ; https://www.gov.uk/student-visa/how-much-it-costs ; https://www.gov.uk/student-visa/money ; https://www.gov.uk/healthcare-immigration-application/how-much-pay ; https://www.postgraduate.study.cam.ac.uk/apply/how/application-fee

## États-Unis

Repères vérifiés : calendrier généralement Fall (août/septembre), Spring (janvier), Summer (mai/juin), mais aucune date nationale. UW donne par exemple le 15 novembre pour Autumn first-year international; Purdue exige tous les éléments avant l’heure limite du terme. Exemples de coûts officiels : Purdue 2025/26 tuition/frais 32 104 USD et logement/nourriture 13 720 USD; Minnesota 2026/27 tuition/frais 44 743 USD, vie 23 669 USD/12 mois, assurance 3 590 USD; UW 2026/27 undergraduate nonresident 61 052 USD/4 trimestres, vie 31 120 USD, assurance 2 148 USD. Visa F/M 185 USD, SEVIS I-901 F/M 350 USD; les frais de réciprocité dépendent de la nationalité et la page Burundi/Rwanda affichait None pour F-1. Tests Minnesota : TOEFL 4,5, IELTS 6,5, PTE 59, Cambridge 180, DET 120 selon la page consultée. Aucun seuil académique universel pour Burundi/Rwanda, Edexcel ou SAT.

Sources : https://admit.washington.edu/apply/freshman/ ; https://admissions.purdue.edu/apply/deadlines/ ; https://www.purdue.edu/treasurer/finance/bursar-office/tuition/fee-rates-2025-2026/undergraduate-tuition-and-fees-2025-2026/ ; https://admissions.tc.umn.edu/cost-aid/cost-aid-scholarships/costs-scholarships-and-visas-international-students ; https://iss.washington.edu/annual-expenses/ ; https://travel.state.gov/content/travel/en/us-visas/visa-information-resources/fees/fees-visa-services.html ; https://www.ice.gov/sevis/i901/faq ; https://admissions.tc.umn.edu/admissions/international-admission/english-proficiency-information

## Espace Schengen — exemples France, Allemagne, Belgique, Pays-Bas

Repères vérifiés : rentrée généralement septembre/octobre; KU Leuven 2026/27, cours du premier semestre le 21 septembre, examens janvier; second semestre le 8 février, examens juin. UvA : selon Bachelor, repères 15 janvier, 1er février, 1er avril ou 1er mai. Allemagne : coût DAAD/Study in Germany environ 900–1 200 EUR/mois; logement 290–560 EUR/mois. France hors UE : 2 902 EUR Licence et 3 950 EUR Master; KU Leuven candidature 90 EUR; UvA Master international 100 EUR. France visa EEF 50 EUR ou 99 EUR; Allemagne visa national 75 EUR; Pays-Bas permis étude IND 254 EUR; Belgique à vérifier selon poste consulaire. KU Leuven : IELTS 6,5, TOEFL 79, Cambridge C1/C2; Duolingo non accepté selon page consultée.

Sources : https://www.kuleuven.be/english/about-kuleuven/calendars/2026-2027/ku-leuven-leuven ; https://www.uva.nl/en/education/admissions/bachelors/applying-for-a-degree-programme.html ; https://www.uva.nl/en/education/admissions/masters/applying-for-a-degree-programme.html ; https://www.study-in-germany.com/en/plan-your-studies/preparation/funding/ ; https://www.daad.de/en/studying-in-germany/requirements/ ; https://www.ind.nl/en/fees-costs-of-an-application ; https://www.kuleuven.be/english/apply/language-requirements/english-proficiency-tests

## Règle de présentation

Présenter les montants comme « repères issus de la page officielle consultée », avec devise et année. Ajouter systématiquement : vérifier la page du programme et le barème immigration avant paiement; les équivalences des diplômes Burundi/Rwanda, les exemptions linguistiques et les seuils SAT/Edexcel varient et ne doivent pas être généralisés. Les frais annexes fréquents sont biométrie, centre de dépôt, assurance, traduction/légalisation, examen médical, certificat de police, test linguistique, logement/caution, transport et validation/titre de séjour selon pays.

## Complément — catégories de visa et visa visiteur USA

Le guide a été complété avec une rubrique « Toutes catégories de visa ». Les repères ajoutés distinguent les visites, études, travail, famille/résidence et les frais annexes. Pour les États-Unis, le visa visiteur B-1/B-2 est présenté avec ses conditions centrales : motif temporaire autorisé, intention de départ, ressources, attaches, admissibilité, DS-160, entretien et frais consulaire non remboursable de 185 USD. Les catégories F/M/J, H/L/O/P/Q/R, E et K sont distinguées avec leurs frais consulaires de référence et les frais SEVIS ou USCIS lorsqu’applicables.

Sources officielles complémentaires : https://travel.state.gov/content/travel/en/us-visas/tourism-visit/visitor.html ; https://travel.state.gov/content/travel/en/us-visas/visa-information-resources/fees/fees-visa-services.html ; https://www.ice.gov/sevis/i901 ; https://www.uscis.gov/g-1055 ; https://www.canada.ca/en/immigration-refugees-citizenship/services/fees.html ; https://www.gov.uk/government/publications/visa-regulations-revised-table ; https://france-visas.gouv.fr/frais-de-visa ; https://home-affairs.ec.europa.eu/policies/schengen-borders-and-visa/visa-policy_en ; https://dofi.ibz.be/en/themes/third-country-nationals/visa ; https://www.ind.nl/en/fees-costs-of-an-application.

Tous les frais restent susceptibles de changer selon la date, la nationalité, le poste consulaire, la catégorie exacte et les exemptions. Vérifier le barème officiel avant tout paiement.

## Complément — preuves financières

Une section « Preuves financières » a été ajoutée pour chaque destination. Elle distingue les justificatifs habituellement utilisés pour visite, études, travail, famille et résidence : relevés bancaires récents, lettres de banque, fiches de paie, contrats et attestations d’emploi, preuves de congé, bourses, prêts, reçus de tuition, logement, invitations, engagements de prise en charge, pétitions ou contrats d’employeur. La présentation précise qu’une invitation seule ne suffit généralement pas et que les documents doivent démontrer la capacité financière, la cohérence du projet et l’origine des fonds.

Références officielles à vérifier selon la catégorie : https://www.canada.ca/en/immigration-refugees-citizenship/services/visit-canada/eligibility.html ; https://www.canada.ca/en/immigration-refugees-citizenship/services/study-canada/study-permit/get-documents.html ; https://www.gov.uk/government/publications/visitor-visa-guide-to-supporting-documents ; https://www.gov.uk/student-visa/money ; https://france-visas.gouv.fr/en/web/france-visas/your-arrival-in-france ; https://travel.state.gov/content/travel/en/us-visas/tourism-visit/visitor.html ; https://travel.state.gov/content/travel/en/us-visas/study/student-visa.html ; https://dofi.ibz.be/en/themes/third-country-nationals/short-stay ; https://dofi.ibz.be/en/themes/third-country-nationals/study.

Les pièces exactes, périodes de relevés, montants minimums et formats de garantie dépendent du pays, de la nationalité, du poste et de la catégorie. Vérifier la checklist officielle à jour avant dépôt.
