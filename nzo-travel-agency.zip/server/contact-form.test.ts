import { describe, expect, it } from "vitest";
import { buildContactMailto, getCountryCodeFromLocale, isValidWhatsAppNumber } from "../client/src/components/ContactForm";

describe("country dial code detection", () => {
  it("maps browser locale regions and falls back to Burundi", () => {
    expect(getCountryCodeFromLocale("fr-FR")).toBe("+33");
    expect(getCountryCodeFromLocale("en-CA")).toBe("+1");
    expect(getCountryCodeFromLocale("en")).toBe("+257");
  });
});

describe("WhatsApp number validation", () => {
  it("accepts international E.164 numbers", () => {
    expect(isValidWhatsAppNumber("+25768457000")).toBe(true);
    expect(isValidWhatsAppNumber("+33612345678")).toBe(true);
  });

  it("rejects local, spaced, malformed and overlong numbers", () => {
    expect(isValidWhatsAppNumber("068457000")).toBe(false);
    expect(isValidWhatsAppNumber("+257 68457000")).toBe(false);
    expect(isValidWhatsAppNumber("+00068457000")).toBe(false);
    expect(isValidWhatsAppNumber("+25768457000123456")).toBe(false);
  });
});

describe("contact form email", () => {
  it("targets NZO and includes the required project details", () => {
    const mailto = buildContactMailto({
      firstName: "Aline",
      lastName: "Niyonzima",
      whatsapp: "+257 68 45 70 00",
      visa: "Permis d’études",
      country: "Canada",
      message: "Je souhaite commencer une analyse de mon projet.",
    }, "fr");

    expect(mailto).toContain("mailto:irakozestartup@gmail.com");
    expect(decodeURIComponent(mailto)).toContain("Aline Niyonzima");
    expect(decodeURIComponent(mailto)).toContain("+257 68 45 70 00");
    expect(decodeURIComponent(mailto)).toContain("Permis d’études");
    expect(decodeURIComponent(mailto)).toContain("Canada");
  });
});
