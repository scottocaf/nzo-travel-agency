import { COOKIE_NAME } from "@shared/const";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { createDocument, getDocumentsForUser } from "./db";
import { getSessionCookieOptions } from "./_core/cookies";
import { notifyOwner } from "./_core/notification";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { storagePut } from "./storage";

const MAX_FILE_BYTES = 12 * 1024 * 1024;
const allowedMimeTypes = new Set([
  "application/pdf",
  "image/jpeg",
  "image/png",
  "image/webp",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
]);

const safeFileName = (fileName: string) => {
  const normalized = fileName.normalize("NFKC").replace(/[^a-zA-Z0-9._-]/g, "-");
  return normalized.replace(/-+/g, "-").slice(0, 180) || "document";
};

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),
  documents: router({
    list: protectedProcedure.query(({ ctx }) => getDocumentsForUser(ctx.user.id)),
    upload: protectedProcedure
      .input(z.object({
        fileName: z.string().min(1).max(255),
        mimeType: z.string().min(1).max(160),
        sizeBytes: z.number().int().positive().max(MAX_FILE_BYTES),
        category: z.string().min(1).max(80),
        dataBase64: z.string().min(1),
      }))
      .mutation(async ({ ctx, input }) => {
        if (!allowedMimeTypes.has(input.mimeType)) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Unsupported file type. Use PDF, JPG, PNG, WEBP or Word." });
        }

        const fileBuffer = Buffer.from(input.dataBase64, "base64");
        if (!fileBuffer.length || fileBuffer.length > MAX_FILE_BYTES) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "The file is empty or exceeds the 12 MB limit." });
        }
        if (Math.abs(fileBuffer.length - input.sizeBytes) > 32) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "The uploaded file size could not be verified." });
        }

        const fileName = safeFileName(input.fileName);
        const { key, url } = await storagePut(
          `nzo-documents/${ctx.user.id}/${Date.now()}-${fileName}`,
          fileBuffer,
          input.mimeType,
        );
        const document = await createDocument({
          userId: ctx.user.id,
          originalName: input.fileName,
          storageKey: key,
          storageUrl: url,
          mimeType: input.mimeType,
          sizeBytes: fileBuffer.length,
          category: input.category,
        });

        await notifyOwner({
          title: "Nouveau document reçu — NZO Travel Agency",
          content: `${input.fileName} (${input.category}) a été déposé par ${ctx.user.email ?? ctx.user.name ?? ctx.user.openId}.`,
        });

        return {
          id: document?.id,
          originalName: input.fileName,
          category: input.category,
          sizeBytes: fileBuffer.length,
          createdAt: document?.createdAt,
        };
      }),
  }),
});

export type AppRouter = typeof appRouter;
