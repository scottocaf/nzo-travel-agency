import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

const authenticatedContext = (): TrpcContext => ({
  user: {
    id: 42,
    openId: "upload-test-user",
    email: "client@example.com",
    name: "Upload Test",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  },
  req: { protocol: "https", headers: {} } as TrpcContext["req"],
  res: {} as TrpcContext["res"],
});

describe("documents.upload", () => {
  it("rejects unsupported file types before touching storage", async () => {
    const caller = appRouter.createCaller(authenticatedContext());

    await expect(caller.documents.upload({
      fileName: "passport.exe",
      mimeType: "application/x-msdownload",
      sizeBytes: 4,
      category: "Identity",
      dataBase64: Buffer.from("test").toString("base64"),
    })).rejects.toThrow("Unsupported file type");
  });

  it("rejects a payload whose declared size does not match its bytes", async () => {
    const caller = appRouter.createCaller(authenticatedContext());

    await expect(caller.documents.upload({
      fileName: "passport.pdf",
      mimeType: "application/pdf",
      sizeBytes: 999,
      category: "Identity",
      dataBase64: Buffer.from("test").toString("base64"),
    })).rejects.toThrow("size could not be verified");
  });
});

describe("documents.list", () => {
  it("requires authentication", async () => {
    const caller = appRouter.createCaller({
      user: null,
      req: { protocol: "https", headers: {} } as TrpcContext["req"],
      res: {} as TrpcContext["res"],
    });

    await expect(caller.documents.list()).rejects.toThrow("Please login");
  });
});
